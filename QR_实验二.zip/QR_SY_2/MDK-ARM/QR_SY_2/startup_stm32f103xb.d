qr_sy_2\startup_stm32f103xb.o: startup_stm32f103xb.s
