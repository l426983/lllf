# QR_SY_2 - USART1 interrupt and DMA experiment

## Configuration

- MCU: STM32F103C8T6, 72 MHz
- USART1: PA9/TX, PA10/RX, 115200 bit/s, 8N1
- USART1 global interrupt: enabled, preemption priority 0
- USART1 TX DMA: DMA1 Channel 4, normal mode, priority 1
- Toolchain: Keil MDK-ARM V5

## Implementation

- `HAL_UART_Receive_IT()` receives one command byte and is re-armed in `HAL_UART_RxCpltCallback()`.
- `HAL_UART_Transmit_DMA()` sends `hello windows!\r\n`.
- `HAL_UART_TxCpltCallback()` restarts the normal-mode DMA transfer, producing a continuous stream.
- `#` stops the active TX DMA transfer; `*` starts it again.
- `HAL_UART_ErrorCallback()` re-arms reception after framing, noise, or overrun errors.

DMA reduces CPU involvement; it does not change the configured line speed. At 115200 bit/s and 8N1, each byte occupies 10 serial bits, so the maximum payload rate is 11520 bytes/s before protocol overhead.

Open `MDK-ARM/QR_SY_2.uvprojx`. The checked build log is `MDK-ARM/build.log`.
