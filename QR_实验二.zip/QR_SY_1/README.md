# QR_SY_1 - USART1 polling experiment

## Configuration

- MCU: STM32F103C8T6
- Core clock: 72 MHz (8 MHz HSE, PLL x9)
- USART1: PA9/TX, PA10/RX, 115200 bit/s, 8 data bits, no parity, 1 stop bit
- Toolchain: Keil MDK-ARM V5

## Wiring

- PA9 (TX) -> USB-UART RXD
- PA10 (RX) <- USB-UART TXD
- STM32 GND <-> USB-UART GND

STM32 pins use 3.3 V TTL levels. Do not connect a true RS-232 +/- voltage signal directly to PA9/PA10. Use a 3.3 V USB-TTL adapter, or add a MAX3232 level converter when the PC-side module exposes RS-232 levels.

## Behavior

The main loop transmits `hello windows!\r\n` continuously with no delay. It also polls one received byte with a zero timeout:

- `#`: pause transmission
- `*`: resume transmission

The blocking HAL transmit call does not overrun the STM32 USART because it waits for the peripheral flags. A normal Windows serial driver should also receive the stream without loss at 115200 bit/s. A slow serial-assistant UI can still appear to skip or freeze while rendering, so verify with a receive counter or save-to-file function.

Open `MDK-ARM/QR_SY_1.uvprojx` to build or download. The checked build log is `MDK-ARM/build.log`.
