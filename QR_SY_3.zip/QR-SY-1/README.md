# STM32F103 + 0.96 寸 OLED + AHT20 实验

本目录提供一个基于 STM32 HAL 的最小可移植示例，完成：

- SSD1306 128×64 OLED 的 I²C 初始化、显存绘制和分页刷屏；
- 学号、姓名显示；
- AHT20 温湿度读取、忙状态等待和 CRC-8 校验；
- “门前有棵葡萄树”的 16×16 汉字点阵横向滚动显示。

## 适用硬件

工程按常见的 STM32F103C8T6 / Blue Pill（外部 8 MHz 晶振，72 MHz 系统时钟）配置。若使用的是 F103RCT6、无外部晶振的最小系统板或其他芯片，需要相应修改芯片型号、启动文件和时钟配置。

## 具体接线

| 模块 | STM32F103 | 说明 |
|---|---|---|
| OLED VCC | 3.3 V | 不要接 5 V |
| OLED GND | GND | 与 STM32 共地 |
| OLED SCL | PB6（I2C1_SCL） | 与 AHT20 SCL 并联 |
| OLED SDA | PB7（I2C1_SDA） | 与 AHT20 SDA 并联 |
| AHT20 VCC | 3.3 V | 传感器供电 |
| AHT20 GND | GND | 与 STM32 共地 |
| AHT20 SCL | PB6 | I²C 总线并联 |
| AHT20 SDA | PB7 | I²C 总线并联 |

SDA、SCL 各需要一个 4.7 kΩ 上拉到 3.3 V；很多 OLED/AHT20 模块已经自带上拉，重复上拉过多时可只保留一组。

### ST-Link 下载接线

| ST-Link | Blue Pill |
|---|---|
| 3.3V | 3.3V（可选，仅在确认供电能力时连接） |
| GND | GND |
| SWDIO | PA13 |
| SWCLK | PA14 |
| NRST | NRST（建议连接） |

烧录前将 `BOOT0` 接 GND（0），`BOOT1/PB2` 保持默认；OLED 和 AHT20 不要接 5 V。

## 编译与烧录

1. 安装 Keil MDK-ARM 5、ARM Compiler 6、STM32F1xx Device Family Pack 和 ST-Link 驱动。
2. 打开根目录的 `QR_SY_3.0.uvprojx`。
3. 在 `Options for Target -> Utilities` 选择 `ST-Link Debugger`，点击 `Settings` 确认 SWD；在 `Debug` 页同样选择 ST-Link。
4. 点击 `Rebuild`。无错误后点击 `Download` 烧录。
5. 复位开发板，屏幕会依次显示学号姓名、AHT20 温湿度和滚动汉字。

如果 Keil 提示缺少 `STM32F103C8` Device Pack，请先在 Pack Installer 安装 STMicroelectronics 的 STM32F1xx_DFP；工程源码本身不依赖 CubeMX。

OLED 默认 7-bit 地址为 `0x3C`，HAL 地址写作 `0x78`；AHT20 7-bit 地址为 `0x38`，HAL 地址写作 `0x70`。总线需要上拉电阻，常用 4.7 kΩ。

## CubeMX / 工程接入

本目录已附带 `QR_SY_3.0.uvprojx` Keil MDK 工程和 `MDK-ARM/startup_stm32f103xb.s` 启动文件。使用 Keil MDK5 打开该 uvprojx，目标芯片选择 STM32F103C8，编译器选择 ARM Compiler 6，并在 `Options for Target -> Debug` 中按实际下载器选择 ST-Link。

工程内含精简版 `stm32f1xx_hal.c/.h`，用于本实验的 I2C、SysTick 和 GPIO 初始化，不需要再从 CubeMX 拷贝 HAL 库。

1. 新建 STM32F103 工程，打开 `I2C1`，选择 Standard Mode 100 kHz，生成 HAL 工程。
2. 将 `Core/Inc` 和 `Core/Src` 中的文件加入工程；确保 `main.h` 能被这些文件包含。
3. 在 `main.c` 的外设初始化完成后调用：

```c
#include "oled_demo.h"

int main(void)
{
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_I2C1_Init();
    OLED_Demo_Start(&hi2c1);
    while (1) { }
}
```

4. 当前示例已经配置为学号 `632407030109`、姓名“刘凡”。如需更换个人信息，修改 `oled_demo.c` 顶部的学号宏和 `font16_demo.c` 中的中文 16×16 字模。

## 原理要点

### I²C 时序

总线由 SDA、SCL 和上拉电阻组成，空闲时两线均为高电平。主机产生 START，发送 7 位地址和 R/W 位；从机在第 9 个时钟返回 ACK。数据在 SCL 高电平期间保持稳定，STOP 表示传输结束。OLED 刷屏使用控制字节 `0x40` 表示后续为显示数据，`0x00` 表示后续为命令。

### SSD1306 显存与刷屏

128×64 像素按 8 个 page 组织，每页 128 字节；一个字节的 8 个 bit 对应同一列的 8 个垂直像素。程序先在 `s_fb[1024]` 中绘图，再按 page 连续发送，属于硬件控制器支持的页模式刷屏，避免逐像素 I²C 通信。

### 汉字点阵

常用 16×16 汉字编码占 32 字节：每行 2 字节，最高位对应最左像素。字模软件通常导出“逐行/阴码/高位在前”，若显示镜像或上下颠倒，应检查导出模式并调整位序、页序。

### AHT20 数据换算

触发命令为 `AC 33 00`。返回 7 字节中：`status + 20-bit humidity + 20-bit temperature + CRC`。换算公式：

```text
RH(%) = raw_humidity * 100 / 2^20
T(°C) = raw_temperature * 200 / 2^20 - 50
```

示例同时检查 busy 位和 CRC-8（多项式 `0x31`），通信异常会显示 `AHT20 ERROR`。

## 现象与调试

- 上电后显示学号、姓名，随后显示温度和相对湿度，再横向滚动中文短句。
- OLED 全黑：先检查地址、SDA/SCL 是否接反、是否有上拉，以及逻辑电平。
- 中文乱码：确认字模编码方向；将目标字模替换到 `font16_demo.c`。
- AHT20 校验失败：确认传感器供电、等待测量完成，并避免总线上存在地址冲突。

## U8G2 移植说明

本示例直接使用 SSD1306 HAL 驱动，便于理解 I²C 和点阵原理。若课程要求 U8G2，可保留 `OLED_Update` 之外的硬件接口，将 U8G2 的 `u8x8_byte_hw_i2c` 回调映射到 `HAL_I2C_Master_Transmit`，并在 `setup` 中选择 `u8g2_Setup_ssd1306_i2c_128x64_noname_f`；中文显示使用 U8G2 内置中文字库或自定义字库。这样 GUI 绘制与底层总线驱动分层，便于后续加入菜单、图标和页面切换。
