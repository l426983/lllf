objects\system_stm32f1xx.o: Core\Src\system_stm32f1xx.c
objects\system_stm32f1xx.o: Core\Src\../Inc/stm32f103xb.h
objects\system_stm32f1xx.o: D:\Keil MDK\Keil5 MDK 0\ARM\ARMCC\Bin\..\include\stdint.h
