objects\font16_demo.o: Core\Src\font16_demo.c
objects\font16_demo.o: Core\Src\../Inc/font16_demo.h
objects\font16_demo.o: D:\Keil MDK\Keil5 MDK 0\ARM\ARMCC\Bin\..\include\stdint.h
