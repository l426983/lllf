objects\aht20.o: Core\Src\aht20.c
objects\aht20.o: Core\Src\../Inc/aht20.h
objects\aht20.o: Core\Src\../Inc/main.h
objects\aht20.o: Core\Src\../Inc/stm32f1xx_hal.h
objects\aht20.o: Core\Src\../Inc/stm32f103xb.h
objects\aht20.o: D:\Keil MDK\Keil5 MDK 0\ARM\ARMCC\Bin\..\include\stdint.h
