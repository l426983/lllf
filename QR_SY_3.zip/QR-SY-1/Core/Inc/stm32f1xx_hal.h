#ifndef STM32F1XX_HAL_H
#define STM32F1XX_HAL_H

#include "stm32f103xb.h"

typedef enum { HAL_OK = 0x00U, HAL_ERROR = 0x01U, HAL_BUSY = 0x02U, HAL_TIMEOUT = 0x03U } HAL_StatusTypeDef;
typedef struct { I2C_TypeDef *Instance; uint32_t ClockSpeed; } I2C_HandleTypeDef;

void HAL_Init(void);
uint32_t HAL_GetTick(void);
void HAL_Delay(uint32_t delay);
HAL_StatusTypeDef HAL_I2C_Init(I2C_HandleTypeDef *hi2c);
HAL_StatusTypeDef HAL_I2C_Master_Transmit(I2C_HandleTypeDef *hi2c, uint16_t address, uint8_t *data, uint16_t size, uint32_t timeout);
HAL_StatusTypeDef HAL_I2C_Master_Receive(I2C_HandleTypeDef *hi2c, uint16_t address, uint8_t *data, uint16_t size, uint32_t timeout);

#endif
