#ifndef OLED_SSD1306_H
#define OLED_SSD1306_H

#include "main.h"
#include <stdint.h>

#define OLED_WIDTH       128U
#define OLED_HEIGHT       64U
#define OLED_I2C_ADDR   (0x3CU << 1)

void OLED_Init(I2C_HandleTypeDef *hi2c);
void OLED_Clear(void);
void OLED_Update(void);
void OLED_DrawPixel(uint8_t x, uint8_t y, uint8_t on);
void OLED_DrawChar5x7(uint8_t x, uint8_t y, char c);
void OLED_DrawString(uint8_t x, uint8_t y, const char *text);
void OLED_DrawChinese16(uint8_t x, uint8_t y, const uint8_t glyph[32]);
void OLED_DrawText16(uint8_t x, uint8_t y, const uint8_t (*glyphs)[32], uint8_t count);

#endif
