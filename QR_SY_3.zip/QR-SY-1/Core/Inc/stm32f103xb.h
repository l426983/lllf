#ifndef STM32F103XB_H
#define STM32F103XB_H

#include <stdint.h>

#define __IO volatile
#define __I  volatile const
#define __O  volatile

typedef struct { __IO uint32_t CR, CFGR, CIR, APB2RSTR, APB1RSTR, AHBENR, APB2ENR, APB1ENR, BDCR, CSR; } RCC_TypeDef;
typedef struct { __IO uint32_t ACR, KEYR, OPTKEYR, SR, CR, AR; } FLASH_TypeDef;
typedef struct { __IO uint32_t CRL, CRH, IDR, ODR, BSRR, BRR, LCKR; } GPIO_TypeDef;
typedef struct { __IO uint32_t CR1, CR2, OAR1, OAR2, DR, SR1, SR2, CCR, TRISE; } I2C_TypeDef;
typedef struct { __IO uint32_t CTRL, LOAD, VAL, CALIB; } SysTick_TypeDef;

#define RCC_BASE       0x40021000UL
#define GPIOB_BASE     0x40010C00UL
#define I2C1_BASE      0x40005400UL
#define SYSTICK_BASE   0xE000E010UL
#define RCC            ((RCC_TypeDef *)RCC_BASE)
#define FLASH          ((FLASH_TypeDef *)0x40022000UL)
#define GPIOB          ((GPIO_TypeDef *)GPIOB_BASE)
#define I2C1           ((I2C_TypeDef *)I2C1_BASE)
#define SysTick        ((SysTick_TypeDef *)SYSTICK_BASE)

#define RCC_CR_HSEON        (1UL << 16)
#define RCC_CR_HSERDY       (1UL << 17)
#define RCC_CR_PLLON        (1UL << 24)
#define RCC_CR_PLLRDY       (1UL << 25)
#define RCC_CFGR_SW_PLL     (2UL << 0)
#define RCC_CFGR_SWS_PLL    (2UL << 2)
#define RCC_CFGR_HPRE_DIV1  (0UL << 4)
#define RCC_CFGR_PPRE1_DIV2 (4UL << 8)
#define RCC_CFGR_PPRE2_DIV1 (0UL << 11)
#define RCC_CFGR_PLLSRC     (1UL << 16)
#define RCC_CFGR_PLLMULL9   (7UL << 18)
#define RCC_APB2ENR_IOPBEN  (1UL << 3)
#define RCC_APB2ENR_AFIOEN  (1UL << 0)
#define RCC_APB1ENR_I2C1EN  (1UL << 21)
#define I2C_CR1_PE          (1UL << 0)
#define I2C_CR1_START       (1UL << 8)
#define I2C_CR1_STOP        (1UL << 9)
#define I2C_CR1_ACK         (1UL << 10)
#define I2C_CR1_SWRST       (1UL << 15)
#define I2C_SR1_SB          (1UL << 0)
#define I2C_SR1_ADDR        (1UL << 1)
#define I2C_SR1_BTF         (1UL << 2)
#define I2C_SR1_RXNE        (1UL << 6)
#define I2C_SR1_TXE         (1UL << 7)
#define I2C_SR1_AF          (1UL << 10)
#define I2C_SR2_BUSY        (1UL << 1)
#define SYSTICK_CTRL_ENABLE (1UL << 0)
#define SYSTICK_CTRL_TICKINT (1UL << 1)
#define SYSTICK_CTRL_CLKSOURCE (1UL << 2)

extern uint32_t SystemCoreClock;
void SystemInit(void);

#endif
