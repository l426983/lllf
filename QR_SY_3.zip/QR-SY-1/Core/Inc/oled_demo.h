#ifndef OLED_DEMO_H
#define OLED_DEMO_H

#include "main.h"

void OLED_Demo_Start(I2C_HandleTypeDef *hi2c);

#endif
