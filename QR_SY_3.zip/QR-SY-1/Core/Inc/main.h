#ifndef MAIN_H
#define MAIN_H

#include "stm32f1xx_hal.h"

extern I2C_HandleTypeDef hi2c1;
void SystemClock_Config(void);

#endif
