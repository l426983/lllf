#ifndef FONT16_DEMO_H
#define FONT16_DEMO_H

#include <stdint.h>

/* 16x16 点阵，逐行、MSB 在左。以下字模可直接替换为 PCtoLCD2002 导出的正式字模。 */
extern const uint8_t FONT_MEN[32];
extern const uint8_t FONT_QIAN[32];
extern const uint8_t FONT_YOU[32];
extern const uint8_t FONT_KE[32];
extern const uint8_t FONT_PU[32];
extern const uint8_t FONT_TAO[32];
extern const uint8_t FONT_SHU[32];
extern const uint8_t FONT_LIU[32];
extern const uint8_t FONT_FAN[32];

extern const uint8_t *const VINEYARD_TEXT[7];

#endif
