#ifndef AHT20_H
#define AHT20_H

#include "main.h"
#include <stdint.h>

#define AHT20_I2C_ADDR (0x38U << 1)

typedef struct {
    float temperature_c;
    float humidity_rh;
} AHT20_Measurement;

HAL_StatusTypeDef AHT20_Init(I2C_HandleTypeDef *hi2c);
HAL_StatusTypeDef AHT20_Read(I2C_HandleTypeDef *hi2c, AHT20_Measurement *measurement);

#endif
