#include "../Inc/aht20.h"

static uint8_t aht20_crc8(const uint8_t *data, uint8_t length)
{
    uint8_t crc = 0xFFU;
    for (uint8_t i = 0; i < length; ++i) {
        crc ^= data[i];
        for (uint8_t bit = 0; bit < 8U; ++bit) crc = (crc & 0x80U) ? (uint8_t)((crc << 1U) ^ 0x31U) : (uint8_t)(crc << 1U);
    }
    return crc;
}

HAL_StatusTypeDef AHT20_Init(I2C_HandleTypeDef *hi2c)
{
    uint8_t status = 0U;
    HAL_StatusTypeDef result = HAL_I2C_Master_Receive(hi2c, AHT20_I2C_ADDR, &status, 1U, 100U);
    if (result != HAL_OK) return result;
    if ((status & 0x08U) == 0U) return HAL_OK;

    uint8_t command[3] = {0xBEU, 0x08U, 0x00U};
    result = HAL_I2C_Master_Transmit(hi2c, AHT20_I2C_ADDR, command, sizeof(command), 100U);
    HAL_Delay(10U);
    return result;
}

HAL_StatusTypeDef AHT20_Read(I2C_HandleTypeDef *hi2c, AHT20_Measurement *measurement)
{
    uint8_t trigger[3] = {0xACU, 0x33U, 0x00U};
    uint8_t data[7] = {0};
    HAL_StatusTypeDef result = HAL_I2C_Master_Transmit(hi2c, AHT20_I2C_ADDR, trigger, sizeof(trigger), 100U);
    if (result != HAL_OK) return result;

    for (uint8_t retry = 0; retry < 20U; ++retry) {
        HAL_Delay(5U);
        result = HAL_I2C_Master_Receive(hi2c, AHT20_I2C_ADDR, data, sizeof(data), 100U);
        if (result != HAL_OK) return result;
        if ((data[0] & 0x80U) == 0U) break;
        if (retry == 19U) return HAL_TIMEOUT;
    }
    if (aht20_crc8(data, 6U) != data[6]) return HAL_ERROR;

    uint32_t raw_humidity = ((uint32_t)data[1] << 12U) | ((uint32_t)data[2] << 4U) | (data[3] >> 4U);
    uint32_t raw_temperature = (((uint32_t)data[3] & 0x0FU) << 16U) | ((uint32_t)data[4] << 8U) | data[5];
    measurement->humidity_rh = ((float)raw_humidity * 100.0f) / 1048576.0f;
    measurement->temperature_c = ((float)raw_temperature * 200.0f) / 1048576.0f - 50.0f;
    return HAL_OK;
}
