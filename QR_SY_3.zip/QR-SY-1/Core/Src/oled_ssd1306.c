#include "../Inc/oled_ssd1306.h"
#include <string.h>

static I2C_HandleTypeDef *s_hi2c;
static uint8_t s_fb[OLED_WIDTH * OLED_HEIGHT / 8U];

static HAL_StatusTypeDef oled_cmd(uint8_t cmd)
{
    uint8_t packet[2] = {0x00U, cmd};
    return HAL_I2C_Master_Transmit(s_hi2c, OLED_I2C_ADDR, packet, 2U, 100U);
}

static const uint8_t font5x7[96][5] = {
    [32] = {0, 0, 0, 0, 0},
    ['0' - 32] = {0x3E, 0x51, 0x49, 0x45, 0x3E},
    ['1' - 32] = {0x00, 0x42, 0x7F, 0x40, 0x00},
    ['2' - 32] = {0x42, 0x61, 0x51, 0x49, 0x46},
    ['3' - 32] = {0x21, 0x41, 0x45, 0x4B, 0x31},
    ['4' - 32] = {0x18, 0x14, 0x12, 0x7F, 0x10},
    ['5' - 32] = {0x27, 0x45, 0x45, 0x45, 0x39},
    ['6' - 32] = {0x3C, 0x4A, 0x49, 0x49, 0x30},
    ['7' - 32] = {0x01, 0x71, 0x09, 0x05, 0x03},
    ['8' - 32] = {0x36, 0x49, 0x49, 0x49, 0x36},
    ['9' - 32] = {0x06, 0x49, 0x49, 0x29, 0x1E},
    ['.' - 32] = {0x00, 0x60, 0x60, 0x00, 0x00},
    [':' - 32] = {0x00, 0x36, 0x36, 0x00, 0x00},
    ['%' - 32] = {0x63, 0x13, 0x08, 0x64, 0x63},
    ['-' - 32] = {0x08, 0x08, 0x08, 0x08, 0x08},
    ['A' - 32] = {0x7E, 0x11, 0x11, 0x11, 0x7E},
    ['B' - 32] = {0x7F, 0x49, 0x49, 0x49, 0x36},
    ['C' - 32] = {0x3E, 0x41, 0x41, 0x41, 0x22},
    ['D' - 32] = {0x7F, 0x41, 0x41, 0x22, 0x1C},
    ['E' - 32] = {0x7F, 0x49, 0x49, 0x49, 0x41},
    ['F' - 32] = {0x7F, 0x09, 0x09, 0x09, 0x01},
    ['G' - 32] = {0x3E, 0x41, 0x49, 0x49, 0x7A},
    ['H' - 32] = {0x7F, 0x08, 0x08, 0x08, 0x7F},
    ['I' - 32] = {0x00, 0x41, 0x7F, 0x41, 0x00},
    ['J' - 32] = {0x20, 0x40, 0x41, 0x3F, 0x01},
    ['K' - 32] = {0x7F, 0x08, 0x14, 0x22, 0x41},
    ['L' - 32] = {0x7F, 0x40, 0x40, 0x40, 0x40},
    ['M' - 32] = {0x7F, 0x02, 0x0C, 0x02, 0x7F},
    ['N' - 32] = {0x7F, 0x04, 0x08, 0x10, 0x7F},
    ['O' - 32] = {0x3E, 0x41, 0x41, 0x41, 0x3E},
    ['P' - 32] = {0x7F, 0x09, 0x09, 0x09, 0x06},
    ['Q' - 32] = {0x3E, 0x41, 0x51, 0x21, 0x5E},
    ['R' - 32] = {0x7F, 0x09, 0x19, 0x29, 0x46},
    ['S' - 32] = {0x46, 0x49, 0x49, 0x49, 0x31},
    ['T' - 32] = {0x01, 0x01, 0x7F, 0x01, 0x01},
    ['U' - 32] = {0x3F, 0x40, 0x40, 0x40, 0x3F},
    ['V' - 32] = {0x1F, 0x20, 0x40, 0x20, 0x1F},
    ['W' - 32] = {0x3F, 0x40, 0x38, 0x40, 0x3F},
    ['X' - 32] = {0x63, 0x14, 0x08, 0x14, 0x63},
    ['Y' - 32] = {0x07, 0x08, 0x70, 0x08, 0x07},
    ['Z' - 32] = {0x61, 0x51, 0x49, 0x45, 0x43}
};

static void oled_set_page(uint8_t page)
{
    oled_cmd((uint8_t)(0xB0U | page));
    oled_cmd(0x00U);
    oled_cmd(0x10U);
}

void OLED_Init(I2C_HandleTypeDef *hi2c)
{
    s_hi2c = hi2c;
    HAL_Delay(20U);
    const uint8_t init_cmds[] = {
        0xAE, 0x20, 0x00, 0xB0, 0xC8, 0x00, 0x10, 0x40,
        0x81, 0x7F, 0xA1, 0xA6, 0xA8, 0x3F, 0xA4, 0xD3,
        0x00, 0xD5, 0x80, 0xD9, 0xF1, 0xDA, 0x12, 0xDB,
        0x20, 0x8D, 0x14, 0xAF
    };
    for (uint32_t i = 0; i < sizeof(init_cmds); ++i) oled_cmd(init_cmds[i]);
    OLED_Clear();
    OLED_Update();
}

void OLED_Clear(void)
{
    memset(s_fb, 0, sizeof(s_fb));
}

void OLED_Update(void)
{
    uint8_t packet[OLED_WIDTH + 1U];
    packet[0] = 0x40U;
    for (uint8_t page = 0; page < 8U; ++page) {
        oled_set_page(page);
        memcpy(&packet[1], &s_fb[(uint16_t)page * OLED_WIDTH], OLED_WIDTH);
        HAL_I2C_Master_Transmit(s_hi2c, OLED_I2C_ADDR, packet, sizeof(packet), 100U);
    }
}

void OLED_DrawPixel(uint8_t x, uint8_t y, uint8_t on)
{
    if (x >= OLED_WIDTH || y >= OLED_HEIGHT) return;
    uint16_t index = (uint16_t)x + ((uint16_t)(y / 8U) * OLED_WIDTH);
    if (on) s_fb[index] |= (uint8_t)(1U << (y & 7U));
    else s_fb[index] &= (uint8_t)~(1U << (y & 7U));
}

void OLED_DrawChar5x7(uint8_t x, uint8_t y, char c)
{
    if (c < 32 || c > 127) c = '?';
    for (uint8_t col = 0; col < 5U; ++col) {
        uint8_t bits = (c <= 127) ? font5x7[(uint8_t)c - 32U][col] : 0U;
        for (uint8_t row = 0; row < 7U; ++row) OLED_DrawPixel((uint8_t)(x + col), (uint8_t)(y + row), (uint8_t)((bits >> row) & 1U));
    }
}

void OLED_DrawString(uint8_t x, uint8_t y, const char *text)
{
    while (*text && x <= OLED_WIDTH - 6U) {
        OLED_DrawChar5x7(x, y, *text++);
        x = (uint8_t)(x + 6U);
    }
}

void OLED_DrawChinese16(uint8_t x, uint8_t y, const uint8_t glyph[32])
{
    for (uint8_t row = 0; row < 16U; ++row) {
        uint8_t left = glyph[row * 2U];
        uint8_t right = glyph[row * 2U + 1U];
        for (uint8_t bit = 0; bit < 8U; ++bit) {
            OLED_DrawPixel((uint8_t)(x + bit), (uint8_t)(y + row), (uint8_t)((left >> (7U - bit)) & 1U));
            OLED_DrawPixel((uint8_t)(x + 8U + bit), (uint8_t)(y + row), (uint8_t)((right >> (7U - bit)) & 1U));
        }
    }
}

void OLED_DrawText16(uint8_t x, uint8_t y, const uint8_t (*glyphs)[32], uint8_t count)
{
    for (uint8_t i = 0; i < count; ++i) OLED_DrawChinese16((uint8_t)(x + i * 16U), y, glyphs[i]);
}
