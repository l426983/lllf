#include "../Inc/main.h"
#include "../Inc/oled_demo.h"

I2C_HandleTypeDef hi2c1 = { I2C1, 100000UL };

void SystemClock_Config(void) { }

int main(void)
{
    HAL_Init();
    SystemClock_Config();
    (void)HAL_I2C_Init(&hi2c1);
    OLED_Demo_Start(&hi2c1);
    while (1) { }
}
