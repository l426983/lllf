#include "../Inc/stm32f1xx_hal.h"

static volatile uint32_t s_tick;

void HAL_Init(void)
{
    s_tick = 0U;
    SysTick->LOAD = (SystemCoreClock / 1000UL) - 1UL;
    SysTick->VAL = 0U;
    SysTick->CTRL = SYSTICK_CTRL_CLKSOURCE | SYSTICK_CTRL_TICKINT | SYSTICK_CTRL_ENABLE;
}

uint32_t HAL_GetTick(void) { return s_tick; }
void SysTick_Handler(void) { ++s_tick; }
void HAL_Delay(uint32_t delay) { uint32_t start = s_tick; while ((s_tick - start) < delay) { } }

static HAL_StatusTypeDef i2c_wait_sr1(I2C_TypeDef *i2c, uint32_t mask, uint8_t set, uint32_t timeout)
{
    uint32_t start = s_tick;
    while ((((i2c->SR1 & mask) != 0U) ? 1U : 0U) != set) {
        if ((s_tick - start) > timeout) return HAL_TIMEOUT;
    }
    return HAL_OK;
}

static HAL_StatusTypeDef i2c_wait_idle(I2C_TypeDef *i2c, uint32_t timeout)
{
    uint32_t start = s_tick;
    while ((i2c->SR2 & I2C_SR2_BUSY) != 0U) {
        if ((s_tick - start) > timeout) return HAL_TIMEOUT;
    }
    return HAL_OK;
}

HAL_StatusTypeDef HAL_I2C_Init(I2C_HandleTypeDef *hi2c)
{
    I2C_TypeDef *i2c = hi2c->Instance;
    RCC->APB2ENR |= RCC_APB2ENR_IOPBEN | RCC_APB2ENR_AFIOEN;
    RCC->APB1ENR |= RCC_APB1ENR_I2C1EN;
    GPIOB->CRL &= ~(0xFFUL << 24);
    GPIOB->CRL |= (0xFFUL << 24); /* PB6/PB7: AF open-drain, 50 MHz */
    i2c->CR1 = I2C_CR1_SWRST;
    i2c->CR1 = 0U;
    i2c->CR2 = 36U;
    i2c->CCR = 180U;
    i2c->TRISE = 37U;
    i2c->CR1 = I2C_CR1_PE;
    return HAL_OK;
}

HAL_StatusTypeDef HAL_I2C_Master_Transmit(I2C_HandleTypeDef *hi2c, uint16_t address, uint8_t *data, uint16_t size, uint32_t timeout)
{
    I2C_TypeDef *i2c = hi2c->Instance;
    if (i2c_wait_idle(i2c, timeout) != HAL_OK) return HAL_BUSY;
    i2c->CR1 |= I2C_CR1_START;
    if (i2c_wait_sr1(i2c, I2C_SR1_SB, 1U, timeout) != HAL_OK) return HAL_TIMEOUT;
    i2c->DR = address & 0xFEU;
    if (i2c_wait_sr1(i2c, I2C_SR1_ADDR, 1U, timeout) != HAL_OK) {
        i2c->CR1 |= I2C_CR1_STOP;
        i2c->SR1 &= ~I2C_SR1_AF;
        return HAL_TIMEOUT;
    }
    (void)i2c->SR2;
    for (uint16_t n = 0; n < size; ++n) {
        if (i2c_wait_sr1(i2c, I2C_SR1_TXE, 1U, timeout) != HAL_OK) { i2c->CR1 |= I2C_CR1_STOP; return HAL_TIMEOUT; }
        i2c->DR = data[n];
    }
    if (i2c_wait_sr1(i2c, I2C_SR1_BTF, 1U, timeout) != HAL_OK) return HAL_TIMEOUT;
    i2c->CR1 |= I2C_CR1_STOP;
    return HAL_OK;
}

HAL_StatusTypeDef HAL_I2C_Master_Receive(I2C_HandleTypeDef *hi2c, uint16_t address, uint8_t *data, uint16_t size, uint32_t timeout)
{
    I2C_TypeDef *i2c = hi2c->Instance;
    if (size == 0U) return HAL_OK;
    if (i2c_wait_idle(i2c, timeout) != HAL_OK) return HAL_BUSY;
    i2c->CR1 |= I2C_CR1_START;
    if (i2c_wait_sr1(i2c, I2C_SR1_SB, 1U, timeout) != HAL_OK) return HAL_TIMEOUT;
    i2c->DR = address | 0x01U;
    if (i2c_wait_sr1(i2c, I2C_SR1_ADDR, 1U, timeout) != HAL_OK) {
        i2c->CR1 |= I2C_CR1_STOP;
        i2c->SR1 &= ~I2C_SR1_AF;
        return HAL_TIMEOUT;
    }
    if (size == 1U) {
        i2c->CR1 &= ~I2C_CR1_ACK;
        (void)i2c->SR2;
        i2c->CR1 |= I2C_CR1_STOP;
        if (i2c_wait_sr1(i2c, I2C_SR1_RXNE, 1U, timeout) != HAL_OK) return HAL_TIMEOUT;
        data[0] = (uint8_t)i2c->DR;
        return HAL_OK;
    }
    (void)i2c->SR2;
    i2c->CR1 |= I2C_CR1_ACK;
    for (uint16_t n = 0; n < size - 2U; ++n) {
        if (i2c_wait_sr1(i2c, I2C_SR1_RXNE, 1U, timeout) != HAL_OK) return HAL_TIMEOUT;
        data[n] = (uint8_t)i2c->DR;
    }
    if (i2c_wait_sr1(i2c, I2C_SR1_RXNE, 1U, timeout) != HAL_OK) return HAL_TIMEOUT;
    data[size - 2U] = (uint8_t)i2c->DR;
    i2c->CR1 &= ~I2C_CR1_ACK;
    i2c->CR1 |= I2C_CR1_STOP;
    if (i2c_wait_sr1(i2c, I2C_SR1_RXNE, 1U, timeout) != HAL_OK) return HAL_TIMEOUT;
    data[size - 1U] = (uint8_t)i2c->DR;
    return HAL_OK;
}
