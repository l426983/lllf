param([string]$KeilBin = 'D:\Keil MDK\Keil5 MDK 0\ARM\ARMCC\Bin')
$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path $PSScriptRoot -Parent
Push-Location $taskRoot
try {
    [xml]$project = Get-Content '.\QR_SY_3.uvprojx' -Raw
    $target = $project.Project.Targets.Target
    $buildOutput = Join-Path $taskRoot 'Objects'
    New-Item -ItemType Directory -Path $buildOutput -Force | Out-Null
    $compilerArgs = @('--cpu','Cortex-M3','--c99','--apcs=interwork','-O2','-Ospace','--split_sections','-g','-DUSE_HAL_DRIVER','-DSTM32F103xB')
    foreach ($include in $target.TargetOption.TargetArmAds.Cads.VariousControls.IncludePath.Split(';')) {
        $compilerArgs += '-I' + $include
    }
    $objects = @()
    foreach ($group in $target.Groups.Group) {
        foreach ($file in $group.Files.File) {
            $path = [string]$file.FilePath
            $object = Join-Path $buildOutput ([IO.Path]::GetFileNameWithoutExtension($path) + '.o')
            Write-Output "Compiling $path"
            if ($file.FileType -eq '2') {
                & "$KeilBin\armasm.exe" --cpu Cortex-M3 --apcs=interwork -g -o $object $path
            } else {
                & "$KeilBin\armcc.exe" @compilerArgs -c $path -o $object
            }
            if ($LASTEXITCODE -ne 0) { throw "Compile failed: $path" }
            $objects += $object
        }
    }
    & "$KeilBin\armlink.exe" @objects --scatter 'MDK-ARM\QR_SY_3.sct' --map --symbols --info sizes,totals,unused --list 'Objects\QR_SY_3.map' --output 'Objects\QR_SY_3.axf'
    if ($LASTEXITCODE -ne 0) { throw 'Link failed' }
    & "$KeilBin\fromelf.exe" --i32combined --output 'Objects\QR_SY_3.hex' 'Objects\QR_SY_3.axf'
    if ($LASTEXITCODE -ne 0) { throw 'HEX conversion failed' }
    Get-Item 'Objects\QR_SY_3.axf','Objects\QR_SY_3.hex' | Select-Object Name,Length,LastWriteTime
    Write-Output 'BUILD OK'
} finally { Pop-Location }
