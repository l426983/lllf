"""Run the linked Cortex-M3 rendering code and export its real framebuffer.

Requires unicorn, pyelftools, Pillow and numpy. Hardware tick and I2C send are
stubbed; this verifies drawing, not STM32 clocks, wiring or bus operation.
"""
from pathlib import Path
from elftools.elf.elffile import ELFFile
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_THUMB, UC_MODE_MCLASS, UC_HOOK_CODE
from unicorn.arm_const import (
    UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3,
    UC_ARM_REG_SP, UC_ARM_REG_LR, UC_ARM_REG_PC,
)

ROOT = Path(__file__).resolve().parents[1]


class FirmwareRenderer:
    def __init__(self):
        self.cpu = Uc(UC_ARCH_ARM, UC_MODE_THUMB | UC_MODE_MCLASS)
        self.cpu.mem_map(0x08000000, 0x20000)
        self.cpu.mem_map(0x20000000, 0x5000)
        with (ROOT / 'Objects/QR_SY_3.axf').open('rb') as stream:
            elf = ELFFile(stream)
            self.symbols = {s.name: int(s['st_value']) for s in
                            elf.get_section_by_name('.symtab').iter_symbols()}
            for section in elf.iter_sections():
                if section['sh_flags'] & 2 and section['sh_type'] != 'SHT_NOBITS':
                    self.cpu.mem_write(int(section['sh_addr']), section.data())
        self.tick = 0
        for name in ('HAL_GetTick', 'u8g2_SendBuffer'):
            address = self.symbols[name] & ~1
            self.cpu.hook_add(UC_HOOK_CODE, self.stub, name, address, address)
        self.call('u8g2_Setup_ssd1306_i2c_128x64_noname_f',
                  self.symbols['g_u8g2'], self.symbols['u8g2_cb_r0'],
                  self.symbols['byte_hal_i2c'], self.symbols['gpio_delay'])
        self.call('DisplayDemo_Init')

    def stub(self, cpu, address, size, name):
        if name == 'HAL_GetTick':
            cpu.reg_write(UC_ARM_REG_R0, self.tick)
        cpu.reg_write(UC_ARM_REG_PC, cpu.reg_read(UC_ARM_REG_LR))

    def call(self, name, *arguments):
        for register, value in zip((UC_ARM_REG_R0, UC_ARM_REG_R1,
                                    UC_ARM_REG_R2, UC_ARM_REG_R3), arguments):
            self.cpu.reg_write(register, value)
        self.cpu.reg_write(UC_ARM_REG_SP, 0x20004F00)
        self.cpu.reg_write(UC_ARM_REG_LR, 0x0801F001)
        self.cpu.emu_start(self.symbols[name] | 1, 0x0801F000, count=2000000)
        if self.cpu.reg_read(UC_ARM_REG_PC) != 0x0801F000:
            raise RuntimeError(f'{name} did not return')

    def draw(self, tick):
        self.tick = tick & 0xFFFFFFFF
        self.call('DisplayDemo_Draw')
        data = np.frombuffer(self.cpu.mem_read(self.symbols['buf'], 1024), dtype=np.uint8)
        pages = data.reshape(8, 128)
        pixels = np.zeros((64, 128), dtype=np.uint8)
        for bit in range(8):
            pixels[bit::8] = ((pages >> bit) & 1) * 255
        return Image.fromarray(pixels)


def main():
    assets = ROOT / 'Assets'
    assets.mkdir(exist_ok=True)
    renderer = FirmwareRenderer()
    samples = [(500, '首屏：仅姓名和学号'),
               (5500, '向左滑动 / 进入'), (8500, '向左滑动 / 移出'),
               (14000, '向上滑动 / 进入'), (16000, '向上滑动 / 移出'),
               (20000, '新图片 / 动态星光')]
    sheet = Image.new('RGB', (3 * 512, 2 * 288), '#252525')
    font = ImageFont.truetype('C:/Windows/Fonts/simsun.ttc', 20)
    draw = ImageDraw.Draw(sheet)
    for index, (tick, title) in enumerate(samples):
        bitmap = renderer.draw(tick)
        if index == 0:
            bitmap.resize((768, 384), Image.Resampling.NEAREST).save(assets / 'screen_demo.png')
        if index == 5:
            bitmap.resize((768, 384), Image.Resampling.NEAREST).save(assets / 'screen_portrait.png')
        x, y = index % 3 * 512, index // 3 * 288
        draw.text((x + 8, y + 3), title, font=font, fill='white')
        sheet.paste(bitmap.resize((512, 256), Image.Resampling.NEAREST).convert('RGB'), (x, y + 30))
    sheet.save(assets / 'screens_firmware.png')
    renderer = FirmwareRenderer()
    frames = [renderer.draw(tick).resize((512, 256), Image.Resampling.NEAREST)
              for tick in range(0, 26500, 220)]
    frames[0].save(assets / 'oled_firmware_preview.gif', save_all=True,
                   append_images=frames[1:], duration=220, loop=0)
    # The first frame of the next cycle must reproduce the first boot frame.
    assert renderer.draw(26500).tobytes() == FirmwareRenderer().draw(0).tobytes()
    # The complete area below the identity must stay blank throughout page one.
    first = np.asarray(FirmwareRenderer().draw(500))
    assert not first[34:].any(), 'Unexpected first-page graphics'
    for tick in (1500, 2500):
        identity = np.asarray(FirmwareRenderer().draw(tick))
        assert np.array_equal(first[:34], identity[:34])
        assert not identity[34:].any(), 'Unexpected first-page graphics'
    # Both wrapped lines must have left the top edge before the portrait.
    assert not np.asarray(FirmwareRenderer().draw(18499)).any()
    # Exercise unsigned HAL tick wrap using the same C drawing code.
    wrap = FirmwareRenderer()
    wrap.tick = 0xFFFFFF00
    wrap.call('DisplayDemo_Init')
    assert wrap.draw(0x100).tobytes() == FirmwareRenderer().draw(512).tobytes()
    print('Firmware framebuffer previews exported; cycle and tick-wrap checks passed.')


if __name__ == '__main__':
    main()
