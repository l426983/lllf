#include "u8g2_port.h"
#include "display_demo.h"
#include <string.h>

u8g2_t g_u8g2;
static I2C_HandleTypeDef *s_hi2c;
static uint8_t s_packet[256];
static uint16_t s_length;
static uint8_t s_overflow;
volatile HAL_StatusTypeDef g_oled_i2c_status;

/* U8G2 calls these four messages for each I2C command/data transaction.
 * The CAD layer inserts the SSD1306 control byte (0x00/0x40).
 * HAL expects the 7-bit slave address shifted left by one bit. */
static uint8_t byte_hal_i2c(u8x8_t *u8x8, uint8_t msg,
                           uint8_t arg_int, void *arg_ptr)
{
    switch (msg) {
    case U8X8_MSG_BYTE_INIT:
        return 1U;
    case U8X8_MSG_BYTE_START_TRANSFER:
        s_length = 0U;
        s_overflow = 0U;
        return 1U;
    case U8X8_MSG_BYTE_SEND:
        if (s_length + arg_int > sizeof(s_packet)) {
            s_overflow = 1U;
            return 0U;
        }
        memcpy(s_packet + s_length, arg_ptr, arg_int);
        s_length += arg_int;
        return 1U;
    case U8X8_MSG_BYTE_END_TRANSFER:
        if (s_overflow) return 0U;
        g_oled_i2c_status = HAL_I2C_Master_Transmit(s_hi2c,
            u8x8_GetI2CAddress(u8x8), s_packet, s_length, 100U);
        return g_oled_i2c_status == HAL_OK;
    default:
        return 0U;
    }
}

static uint8_t gpio_delay(u8x8_t *u8x8, uint8_t msg,
                          uint8_t arg_int, void *arg_ptr)
{
    (void)u8x8;
    (void)arg_ptr;
    switch (msg) {
    case U8X8_MSG_DELAY_MILLI:
        HAL_Delay(arg_int);
        break;
    case U8X8_MSG_DELAY_10MICRO:
        for (volatile uint32_t i = 0U; i < (uint32_t)arg_int * 180U; ++i) __NOP();
        break;
    case U8X8_MSG_DELAY_100NANO:
        __NOP();
        break;
    default:
        /* Four-pin I2C OLED modules have no separate reset pin. */
        break;
    }
    return 1U;
}

void U8G2_Port_Init(I2C_HandleTypeDef *hi2c)
{
    uint8_t address = 0x78U;
    s_hi2c = hi2c;
    HAL_Delay(100U);
    if (HAL_I2C_IsDeviceReady(hi2c, 0x78U, 2U, 20U) != HAL_OK &&
        HAL_I2C_IsDeviceReady(hi2c, 0x7AU, 2U, 20U) == HAL_OK) address = 0x7AU;
    u8g2_Setup_ssd1306_i2c_128x64_noname_f(&g_u8g2, U8G2_R0,
        byte_hal_i2c, gpio_delay);
    u8g2_SetI2CAddress(&g_u8g2, address);
    u8g2_InitDisplay(&g_u8g2);
    u8g2_SetPowerSave(&g_u8g2, 0U);
    u8g2_SetContrast(&g_u8g2, 180U);
    u8g2_ClearBuffer(&g_u8g2);
    u8g2_SendBuffer(&g_u8g2);
    DisplayDemo_Init();
}

void U8G2_Port_DrawDemo(void)
{
    DisplayDemo_Draw();
}
