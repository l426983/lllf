#include "display_demo.h"
#include "display_assets.h"
#include "display_strings.h"
#include "u8g2_port.h"

#define DEMO_MS 3000UL
#define HORIZONTAL_MS 9000UL
#define VERTICAL_MS 6500UL
#define PORTRAIT_MS 8000UL

static uint32_t s_page_start;
static uint8_t s_page;
static const uint32_t s_duration[] = {
    DEMO_MS, HORIZONTAL_MS, VERTICAL_MS, PORTRAIT_MS
};

/* The bitmap font is a subset, not a full 20+ KB Chinese font.
 * All coordinates stay signed until AFTER clipping. This prevents a glyph
 * leaving the left/top edge from wrapping around to the opposite edge. */
static uint16_t utf8_next(const char **text)
{
    const uint8_t *p = (const uint8_t *)*text;
    uint16_t cp;
    if (p[0] < 0x80U) { cp = p[0]; *text += 1; }
    else if ((p[0] & 0xE0U) == 0xC0U && p[1] != 0U) {
        cp = (uint16_t)(((p[0] & 0x1FU) << 6) | (p[1] & 0x3FU));
        *text += 2;
    } else if ((p[0] & 0xF0U) == 0xE0U && p[1] != 0U && p[2] != 0U) {
        cp = (uint16_t)(((p[0] & 0x0FU) << 12) | ((p[1] & 0x3FU) << 6) | (p[2] & 0x3FU));
        *text += 3;
    } else { cp = '?'; *text += 1; }
    return cp;
}

static const uint8_t *find_glyph(uint16_t cp)
{
    uint16_t i;
    for (i = 0U; i < g_chinese_glyph_count; ++i)
        if (g_chinese_glyphs[i].unicode == cp) return g_chinese_glyphs[i].xbm;
    return 0;
}

static void text16(int16_t x, int16_t y, const char *text, int16_t clip_top)
{
    while (*text) {
        uint16_t cp = utf8_next(&text);
        const uint8_t *bits;
        if (cp < 128U) {
            if (x >= 0 && x <= 122 && y >= clip_top && y <= 48)
                u8g2_DrawGlyph(&g_u8g2, (u8g2_uint_t)x, (u8g2_uint_t)(y + 3), cp);
            x += 6;
            continue;
        }
        bits = find_glyph(cp);
        if (bits && x > -16 && x < 128 && y > clip_top - 16 && y < 64) {
            if (x >= 0 && x <= 112 && y >= clip_top && y <= 48) {
                u8g2_DrawXBM(&g_u8g2, (u8g2_uint_t)x, (u8g2_uint_t)y, 16U, 16U, bits);
            } else {
                uint8_t row, col;
                for (row = 0U; row < 16U; ++row) {
                    int16_t py = y + row;
                    if (py < clip_top || py >= 64) continue;
                    for (col = 0U; col < 16U; ++col) {
                        int16_t px = x + col;
                        if (px < 0 || px >= 128) continue;
                        if ((bits[row * 2U + col / 8U] >> (col & 7U)) & 1U)
                            u8g2_DrawPixel(&g_u8g2, (u8g2_uint_t)px, (u8g2_uint_t)py);
                    }
                }
            }
        }
        x += 16;
    }
}

static void draw_identity(void)
{
    text16(0, 0, UI_NAME, 0);
    text16(0, 18, UI_ID, 0);
}

static void draw_scroll(uint8_t page, uint32_t ms)
{
    if (page == 1U) {
        /* 10 Chinese characters * 16 px = 160 px. Move fully through both edges. */
        int16_t travel = (int16_t)(ms * 288UL / HORIZONTAL_MS);
        int16_t x = 128 - travel;
        text16(x, 24, UI_WELCOME, 0);
    } else {
        /* Wrap the complete sentence onto two centered lines for vertical motion. */
        int16_t travel = (int16_t)(ms * 100UL / VERTICAL_MS);
        int16_t y = 64 - travel;
        text16(32, y, UI_WELCOME_LINE1, 0);
        text16(16, y + 18, UI_WELCOME_LINE2, 0);
    }
}

static void sparkle(uint8_t x, uint8_t y, uint8_t radius)
{
    u8g2_DrawHLine(&g_u8g2, x - radius, y, radius * 2U + 1U);
    u8g2_DrawVLine(&g_u8g2, x, y - radius, radius * 2U + 1U);
}

static void draw_portrait(uint32_t ms)
{
    static const uint8_t sway[8] = {0U, 1U, 2U, 1U, 0U, 1U, 2U, 1U};
    uint8_t x = (uint8_t)(31U + sway[(ms / 220U) & 7U]);
    if (ms < 1000U) {
        uint8_t reveal = (uint8_t)(ms * 64U / 1000U + 1U);
        u8g2_SetClipWindow(&g_u8g2, 0U, 0U, 128U, reveal);
    }
    u8g2_DrawXBM(&g_u8g2, x, 0U, PORTRAIT_WIDTH, PORTRAIT_HEIGHT, g_portrait_xbm);
    u8g2_SetMaxClipWindow(&g_u8g2);
    sparkle(16U, 20U, (uint8_t)(1U + (ms / 250U) % 3U));
    sparkle(111U, 45U, (uint8_t)(1U + (ms / 350U) % 3U));
}

void DisplayDemo_Init(void)
{
    s_page = 0U;
    s_page_start = HAL_GetTick();
}

void DisplayDemo_Draw(void)
{
    uint32_t now = HAL_GetTick();
    uint32_t elapsed = now - s_page_start;
    while (elapsed >= s_duration[s_page]) {
        s_page_start += s_duration[s_page];
        s_page = (uint8_t)((s_page + 1U) % (sizeof(s_duration) / sizeof(s_duration[0])));
        elapsed = now - s_page_start;
    }
    u8g2_ClearBuffer(&g_u8g2);
    u8g2_SetDrawColor(&g_u8g2, 1U);
    u8g2_SetFont(&g_u8g2, u8g2_font_6x10_tf);
    u8g2_SetFontPosTop(&g_u8g2);
    u8g2_SetFontMode(&g_u8g2, 1U);
    u8g2_SetBitmapMode(&g_u8g2, 1U);
    if (s_page == 0U) draw_identity();
    else if (s_page < 3U) draw_scroll(s_page, elapsed);
    else draw_portrait(elapsed);
    u8g2_SendBuffer(&g_u8g2);
}
