#ifndef DISPLAY_ASSETS_H
#define DISPLAY_ASSETS_H
#include <stdint.h>
typedef struct {
    uint16_t unicode;
    uint8_t xbm[32];
} ChineseGlyph;
extern const ChineseGlyph g_chinese_glyphs[];
extern const uint16_t g_chinese_glyph_count;
extern const uint8_t g_portrait_xbm[512];
#define PORTRAIT_WIDTH 64
#define PORTRAIT_HEIGHT 64
#endif
