#ifndef U8G2_PORT_H
#define U8G2_PORT_H

#include "u8g2.h"
#include "main.h"

extern u8g2_t g_u8g2;
void U8G2_Port_Init(I2C_HandleTypeDef *hi2c);
void U8G2_Port_DrawDemo(void);

#endif
