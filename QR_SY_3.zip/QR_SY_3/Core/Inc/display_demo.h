#ifndef DISPLAY_DEMO_H
#define DISPLAY_DEMO_H
#include "u8g2.h"
void DisplayDemo_Init(void);
void DisplayDemo_Draw(void);
#endif
