objects\u8x8_capture.o: Middlewares\U8G2\csrc\u8x8_capture.c
objects\u8x8_capture.o: Middlewares\U8G2\csrc\u8x8.h
objects\u8x8_capture.o: D:\Keil MDK\Keil5 MDK 0\ARM\ARMCC\Bin\..\include\stdint.h
objects\u8x8_capture.o: D:\Keil MDK\Keil5 MDK 0\ARM\ARMCC\Bin\..\include\stdarg.h
objects\u8x8_capture.o: D:\Keil MDK\Keil5 MDK 0\ARM\ARMCC\Bin\..\include\stddef.h
objects\u8x8_capture.o: D:\Keil MDK\Keil5 MDK 0\ARM\ARMCC\Bin\..\include\limits.h
