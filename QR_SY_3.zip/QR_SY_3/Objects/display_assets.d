objects\display_assets.o: Core\Src\display_assets.c
objects\display_assets.o: Core\Inc\display_assets.h
objects\display_assets.o: D:\Keil MDK\Keil5 MDK 0\ARM\ARMCC\Bin\..\include\stdint.h
