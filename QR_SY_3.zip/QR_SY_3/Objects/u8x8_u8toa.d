objects\u8x8_u8toa.o: Middlewares\U8G2\csrc\u8x8_u8toa.c
objects\u8x8_u8toa.o: Middlewares\U8G2\csrc\u8x8.h
objects\u8x8_u8toa.o: D:\Keil MDK\Keil5 MDK 0\ARM\ARMCC\Bin\..\include\stdint.h
objects\u8x8_u8toa.o: D:\Keil MDK\Keil5 MDK 0\ARM\ARMCC\Bin\..\include\stdarg.h
objects\u8x8_u8toa.o: D:\Keil MDK\Keil5 MDK 0\ARM\ARMCC\Bin\..\include\stddef.h
objects\u8x8_u8toa.o: D:\Keil MDK\Keil5 MDK 0\ARM\ARMCC\Bin\..\include\limits.h
