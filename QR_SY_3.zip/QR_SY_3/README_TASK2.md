# 任务二：STM32F103C8T6 + 官方 HAL + U8G2 + I2C OLED

请打开本目录根部的 **QR_SY_3.uvprojx**，使用 ARMCC 5.06 update 5 编译。
烧录文件为 `Objects/QR_SY_3.hex`。

## 画面和时间

| 顺序 | OLED 内容 | 持续时间 |
|---|---|---|
| 1 | 仅显示“姓名：刘凡”“学号：632407030109”，下方留空 | 3 秒 |
| 2 | “欢迎来到重庆交通大学”从右向左完整经过屏幕 | 9 秒 |
| 3 | 句子分成“欢迎来到”“重庆交通大学”两行，向上滑动并完整移出 | 6.5 秒 |
| 4 | 本次提供的红白兜帽人物图片转为 64×64 黑白点阵，渐显、轻微摆动和星光闪烁 | 8 秒 |

以上四页循环，共 26.5 秒。首屏仅显示姓名和学号，不显示 GraphicsTest Demo 或其他图形。
滚动页面只显示欢迎语，没有方向标题和分隔线。
时间按 `HAL_GetTick()` 计量，包括 I2C 发送时间。
全屏 1024 字节在 100 kHz 总线上传输约 95 ms，目标帧间隔为 110 ms。
修改持续时间可编辑 `Core/Src/display_demo.c` 开头的四个 `*_MS` 宏。
本任务二程序不需要 AHT20；任务一工程没有修改。

## 真正的 U8G2 移植

当前编译的是上游 U8G2 的 C 绘图、字体、SSD1306 和 I2C CAD 驱动，
通过 `Core/Src/u8g2_port.c` 的字节回调调用官方
`HAL_I2C_Master_Transmit()`。没有用任务一 OLED 驱动替代 U8G2。
`Middlewares/U8G2/GraphicsTest_upstream.ino` 保存原始示例供对照。
程序不再显示 GraphicsTest Demo；原始示例文件仅作为移植参考保留，不参与界面显示。
后续中文滚动和图片动画仍由 U8G2 绘制。

裁剪为 SSD1306 128×64 I2C 全缓冲 setup、1024 字节 framebuffer、
6×10 ASCII 字体和必需绘图模块。中文使用 16 个 16×16 子集点阵，
每字 32 字节；肖像为 512 字节。未链接全部设备 setup 和完整大字库。
所有图像、汉字最终均由 U8G2 写入 framebuffer。

横向文字宽度 160 像素，使用有符号坐标进行边缘裁剪，避免坐标回绕。
纵向分两行显示完整句子。这里采用软件移动绘制坐标，并非硬件滚屏命令。
中文字符串位于 `Core/Inc/display_strings.h`，采用明确的 UTF-8 字节转义，
避免 Keil 编码设置改变汉字。点阵按 XBM 格式逐行排列，低位在前。

## 接线保持不变

| OLED 四针模块 | STM32F103C8T6 |
|---|---|
| VCC | 3.3V |
| GND | GND |
| SCL | PB6，I2C1_SCL |
| SDA | PB7，I2C1_SDA |

初始化探测 7 位地址 `0x3C/0x3D`，HAL 实际发送地址为 `0x78/0x7A`。
SCL/SDA 需上拉到 3.3V，常见 OLED 模块已自带上拉。
ST-Link：SWDIO→PA13，SWCLK→PA14，GND→GND；NRST 可选。
BOOT0 保持 0，板子需正常供电。假定外部 8 MHz 晶振，PLL 后为 72 MHz。

## 编译及下载

1. 用 Keil MDK5 打开根目录 `QR_SY_3.uvprojx`。
2. 选择 ARM Compiler 5，点击 Rebuild，再点击 Download。
3. Debug 和 Utilities 选择 ST-Link，接口 SWD。
4. 复位后首先仅显示中文姓名学号，再进入滚动、肖像页面。

也可在 PowerShell 中执行：

```powershell
& 'D:\QR——CSDN\QR_SY_3.0\QR_SY_3\Tools\build_armcc.ps1'
```

脚本读取同一份 `.uvprojx` 的源文件列表与头文件路径，调用本机
ARMCC/armasm/armlink/fromelf，输出 AXF、HEX 和 MAP。
Flash 限制为 64 KB，RAM 限制为 20 KB，启动文件栈为 2 KB。
最终构建结果参见 `Objects/QR_SY_3.map`。
源码编译和画面预览验证不能替代实物烧录确认。

工程已在本机 µVision 5.24a 中验证可打开。
本次修改已用 ARMCC 5.06 update 5 脚本完整编译并生成 `Objects/QR_SY_3.hex`，
编译无错误或警告，并用真实 ARM 固件绘图代码验证所有页面。
工程已修正旧版 Keil 的配置兼容问题，使用无 BOM 的 UTF-8 编码；
再次编辑 `.uvprojx` 时请保持无 BOM，以免该版本提示无法读取工程。
默认调试器为 ST-Link。此次未进行实物烧录。
当前 ARMCC 脚本构建占用 Flash 13412 字节，静态 RAM（含栈/堆）4208 字节。
`Tools/preview_firmware.py` 使用 Unicorn 执行已链接 AXF 的真实 ARM 绘图指令，
仅替代时钟读取和 I2C 发送，将真实 framebuffer 导出为
`Assets/screens_firmware.png` 与 `Assets/oled_firmware_preview.gif`。
它已检查整轮回到首屏、HAL Tick 回绕，预览不是实物屏幕拍摄。

## 肖像与字模再生成

`Tools/generate_assets.py` 默认读取本次图片
`D:/QQ/qq_pic_merged_1792845174430.jpg`。
先按 54×71 色块的内部中位数去掉网格、行号、色号，恢复完整人物图，
再保持比例缩放到 49×64 并居中放入 64×64 点阵，用有序抖动区分红色和黑色。
不裁切人物，不显示原图的表格文字。所有转换在本地进行。
恢复的彩色图为 `Assets/portrait_grid_recovered.png`，
OLED 实际黑白预览为 `Assets/screen_portrait.png`。
已生成的 C 数组可以直接编译，不依赖 Python 或原始照片。
重新生成需要 Pillow 和 numpy；网格恢复参数针对本次 1200×1560 图片，
替换为其他图片时需调整恢复步骤，不能直接套用旧照片的裁切参数。

## 框架来源

`QR_SY_3.ioc` 已由本机 STM32CubeMX 6.18.1 加载、生成并保存。
生成记录保存在 `CubeMX_Generation/generation.log`。
活动工程的 main、MSP、中断源文件及 main/中断头文件使用此次实际生成的框架，
U8G2 的 include、初始化与循环调用放在 main 的 USER CODE 区域。
HAL/CMSIS 来自本机 STM32CubeF1 V1.8.7 官方源码。
`main.c`、`stm32f1xx_hal_msp.c`、`stm32f1xx_it.c` 分别负责
时钟/外设初始化、PB6/PB7 复用开漏配置和 SysTick。
U8G2 通过独立适配层接入 HAL，应用层在 `display_demo.c`。
第三方源码许可随 Drivers 和 Middlewares 目录保留。

CubeMX 再生成时可保留 USER CODE。课程工程中 U8G2 文件组与裁剪的
HAL 配置由根目录 `QR_SY_3.uvprojx` 管理；若 CubeMX 另外生成 MDK-ARM
子目录下的工程，仍请使用根目录工程编译，或手动加入相同的 U8G2 文件组。
