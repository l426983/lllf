#include "ucos_ii.h"
#include "board.h"

__align(8) static OS_STK s_led1_stack[APP_TASK_STACK_WORDS];
__align(8) static OS_STK s_led2_stack[APP_TASK_STACK_WORDS];
__align(8) static OS_STK s_uart_stack[APP_TASK_STACK_WORDS];
__align(8) static OS_STK s_heartbeat_stack[APP_TASK_STACK_WORDS];

/* Watch these symbols in Keil; no extra serial text contaminates the message. */
volatile INT32U g_led1_edges;
volatile INT32U g_led2_edges;
volatile INT32U g_uart_messages;
volatile INT32U g_led1_tick;
volatile INT32U g_led2_tick;
volatile INT32U g_uart_tick;
volatile INT32U g_heartbeat_edges;
volatile INT32U g_heartbeat_tick;

/* Explicit GBK bytes match the serial assistant's fixed receive encoding.
 * Text: hello uc/OS! 欢迎来到RTOS多任务环境！ */
static const char s_message[] =
    "hello uc/OS! "
    "\xBB\xB6\xD3\xAD\xC0\xB4\xB5\xBD"
    "RTOS"
    "\xB6\xE0\xC8\xCE\xCE\xF1\xBB\xB7\xBE\xB3\xA3\xA1\r\n";

static void DelayUntil(INT32U *deadline, INT32U period)
{
    INT32S remaining;
    OS_CPU_SR cpu_sr = 0u;
    *deadline += period;
    /* Prevent a tick between reading time and setting the delay. The nested
     * critical sections in OSTimeGet/OSTimeDly restore the previous PRIMASK.
     * PendSV runs only after this outer critical section is released. */
    OS_ENTER_CRITICAL();
    remaining = (INT32S)(*deadline - OSTimeGet());
    if (remaining > 0) {
        OSTimeDly((INT32U)remaining);
    } else if (remaining < 0) {
        *deadline = OSTimeGet(); /* resync after overrun; avoid catch-up burst */
    }
    OS_EXIT_CRITICAL();
}

static void TaskLED1(void *arg)
{
    INT32U deadline = 0u;
    unsigned int on = 1u;
    (void)arg;
    Board_StartTick(); /* Highest priority task starts the shared time base. */
    for (;;) {
        Board_SetLED(1u, on);
        g_led1_tick = OSTimeGet();
        ++g_led1_edges;
        on ^= 1u;
        DelayUntil(&deadline, APP_LED1_HALF_TICKS);
    }
}

static void TaskLED2(void *arg)
{
    INT32U deadline = 0u;
    unsigned int on = 1u;
    (void)arg;
    for (;;) {
        Board_SetLED(2u, on);
        g_led2_tick = OSTimeGet();
        ++g_led2_edges;
        on ^= 1u;
        DelayUntil(&deadline, APP_LED2_HALF_TICKS);
    }
}

static void TaskUART(void *arg)
{
    INT32U deadline = 0u;
    (void)arg;
    for (;;) {
        DelayUntil(&deadline, APP_UART_PERIOD_TICKS);
        g_uart_tick = OSTimeGet();
        Board_SendString(s_message);
        ++g_uart_messages;
    }
}

static void TaskHeartbeat(void *arg)
{
    INT32U deadline = 0u;
    unsigned int on = 1u;
    (void)arg;
    for (;;) {
        Board_SetHeartbeat(on);
        g_heartbeat_tick = OSTimeGet();
        ++g_heartbeat_edges;
        on ^= 1u;
        DelayUntil(&deadline, APP_HEARTBEAT_HALF_TICKS);
    }
}

static void CreateTask(void (*entry)(void *), OS_STK *stack,
                       INT8U prio, INT8U *name)
{
    INT8U err = OSTaskCreateExt(entry, (void *)0,
        &stack[APP_TASK_STACK_WORDS - 1u], prio, prio,
        &stack[0], APP_TASK_STACK_WORDS, (void *)0,
        OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);
    if (err != OS_ERR_NONE) { Board_Fatal(0x100u | err); }
    OSTaskNameSet(prio, name, &err);
    if (err != OS_ERR_NONE) { Board_Fatal(0x200u | err); }
}

int main(void)
{
    Board_Init();
    OSInit();
    CreateTask(TaskLED1, s_led1_stack, APP_LED1_PRIO, (INT8U *)"LED_2s");
    CreateTask(TaskLED2, s_led2_stack, APP_LED2_PRIO, (INT8U *)"LED_6s");
    CreateTask(TaskUART, s_uart_stack, APP_UART_PRIO, (INT8U *)"UART_2s");
    CreateTask(TaskHeartbeat, s_heartbeat_stack, APP_HEARTBEAT_PRIO,
               (INT8U *)"Heartbeat_2s");
    OSStart();
    Board_Fatal(0xE002u);
    return 0;
}

void HardFault_Handler(void) { Board_Fatal(0xF003u); }
void MemManage_Handler(void) { Board_Fatal(0xF004u); }
void BusFault_Handler(void)  { Board_Fatal(0xF005u); }
void UsageFault_Handler(void){ Board_Fatal(0xF006u); }
