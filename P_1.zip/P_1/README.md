# 任务一：STM32F103 上移植 μC/OS-II，运行三个实验任务与心跳任务

直接打开本目录的 **P_1.uvprojx**，使用 **ARM Compiler 5.06** 编译。
烧录文件：`Objects/P_1.hex`；详细过程见 **移植记录.md**。

## 已实现的功能

| 应用任务 | 优先级（数字越小越高） | 行为 |
|---|---:|---|
| LED_2s | 5 | PB0（LED1），亮 1 s、灭 1 s，完整周期 2 s |
| LED_6s | 6 | PB1（LED2），亮 3 s、灭 3 s，完整周期 6 s |
| UART_2s | 7 | USART1 每 2 s 发送指定文本，第一次在启动约 2 s 时发送 |
| Heartbeat_2s | 8 | PC13 板载状态灯，亮 1 s、灭 1 s，完整周期 2 s |

PC13 心跳由独立低优先级任务驱动，用于观察系统任务调度是否持续运行。
它不能证明所有硬件或任务都无故障；进入 Board_Fatal 时心跳熄灭、LED1/LED2 常亮。

串口文本为：`hello uc/OS! 欢迎来到RTOS多任务环境！`，末尾追加 CRLF。
串口助手设置 **115200、8N1、GBK、不使用流控**；本工程按 GBK 编码发送中文，以兼容固定按 GBK 解码的串口助手。

## 默认硬件和接线

按 **STM32F103C8T6 / Blue Pill，64 KB Flash、20 KB SRAM、8 MHz 外部晶振** 配置。
外部晶振启动失败时回退至内部 HSI 8 MHz，并按实际时钟配置串口及节拍。

| 用途 | 引脚 / 接线 |
|---|---|
| LED1 | PB0，外接：3.3V → 330Ω → LED 阳极，LED 阴极 → PB0 |
| LED2 | PB1，外接：3.3V → 330Ω → LED 阳极，LED 阴极 → PB1 |
| 系统心跳 | PC13，常见 Blue Pill 板载 LED，低电平点亮 |
| 串口发送 | PA9（USART1_TX）→ USB-TTL 的 RX |
| 串口接收 | PA10（USART1_RX）← USB-TTL 的 TX，本实验可不连接 |
| 地线 | STM32 GND 与 USB-TTL GND 共地 |
| 下载 | ST-Link SWDIO→PA13、SWCLK→PA14、GND→GND；BOOT0=0 |

USB-TTL 使用 **3.3V TTL 电平**。LED 引脚和有效电平集中在 `BSP/board.h`；
若使用其他开发板，须依据该板原理图核对 PC13 状态灯，PB0/PB1 按表外接 LED。

## 编译和运行

1. 打开 `P_1.uvprojx`，目标为 `P_1_uCOS_II`，安装 STM32F1xx_DFP。
2. 编译器选择 ARM Compiler 5，点击 Rebuild。
3. Debug/Utilities 选择实际使用的 ST-Link，接口 SWD。
4. 下载后复位；同时观察两只外接 LED、PC13 心跳灯，并在串口助手接收文本。

也可使用 PowerShell：

```powershell
& '.\Tools\build_armcc.ps1'
# 不同 Keil 安装位置可通过 -KeilBin 指定 ARMCC 的 bin 目录。
```

## 验证状态

2026-10-28 已完成本机 Keil Rebuild：**0 Error(s)、0 Warning(s)**。
Flash 3988 字节，静态 RAM（含应用任务栈、空闲栈、主栈、堆）6696 字节。
真实 ARM 固件的 12 秒指令级验证通过：LED1 每 100 tick 切换，LED2 每 300 tick 切换，
PC13 心跳每 100 tick 切换；四个应用任务和一个空闲任务均参与调度。
串口在 200、400、600、800、1000、1200 tick 发送，tick=10ms。
HSE72 和 HSI8 两种时钟路径均通过。日志在 `Objects/verification_*.json`。

**尚未进行实物烧录、示波器测量或真实串口采集。** 指令级验证使用简化外设模型，
不能代替上板验收；详细限制和验收记录表见移植记录。

## 周期含义

按最新要求，“2s/6s 周期”指完整亮灭周期：LED1 每 1 s 翻转一次，LED2 每 3 s 翻转一次。
周期集中在 `Config/app_cfg.h`：`APP_LED1_HALF_TICKS` 为 `OS_TICKS_PER_SEC`，
`APP_LED2_HALF_TICKS` 为 `3u * OS_TICKS_PER_SEC`。
PC13 的翻转间隔可单独通过 `APP_HEARTBEAT_HALF_TICKS` 修改，默认 100 tick=1s。

本工程使用上游 μC/OS-II V2.93.01 的真实内核，来源、固定提交及许可证见
`Middlewares/uCOS-II/UPSTREAM.md`。`Port/` 是本实验的 Cortex-M3/ARMCC5 移植实现。
