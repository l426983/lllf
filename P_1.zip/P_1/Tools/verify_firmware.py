"""Execute the real ARM ELF with Unicorn; model only the peripherals we use.

Requires: unicorn, pyelftools. Run after build_armcc.ps1.
The harness supplies Cortex-M exception entry/return and injects 100 Hz ticks
when idle, rather than claiming a cycle-accurate STM32 or physical-board test.
"""
import argparse
import json
import struct
from pathlib import Path

from elftools.elf.elffile import ELFFile
from unicorn import (Uc, UC_ARCH_ARM, UC_MODE_THUMB, UC_MODE_MCLASS,
                     UC_HOOK_CODE, UC_HOOK_MEM_READ, UC_HOOK_MEM_WRITE)
from unicorn.arm_const import *

ROOT = Path(__file__).resolve().parents[1]
RCC = 0x40021000
UART = 0x40013800
ICSR = 0xE000ED04
SYSTICK = 0xE000E010
REGS = [UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3,
        UC_ARM_REG_R12, UC_ARM_REG_LR, UC_ARM_REG_PC, UC_ARM_REG_XPSR]


class FirmwareCheck:
    def __init__(self, hse=True):
        self.hse = hse
        self.uc = Uc(UC_ARCH_ARM, UC_MODE_THUMB | UC_MODE_MCLASS)
        self.uc.ctl_set_cpu_model(UC_CPU_ARM_CORTEX_M3)
        for address, size in [(0x08000000, 0x10000), (0x20000000, 0x5000),
                              (0x40000000, 0x30000), (0xE000E000, 0x2000)]:
            self.uc.mem_map(address, size)
        self.symbols = {}
        with (ROOT / 'Objects/P_1.axf').open('rb') as src:
            elf = ELFFile(src)
            for segment in elf.iter_segments():
                if segment['p_type'] == 'PT_LOAD' and segment['p_filesz']:
                    # ELF p_paddr includes the ROM load image of RW data.
                    self.uc.mem_write(segment['p_paddr'], segment.data())
            for symbol in elf.get_section_by_name('.symtab').iter_symbols():
                self.symbols[symbol.name] = symbol['st_value']
        self.write32(RCC, 0x83)
        self.write32(UART, 0xC0)  # TXE and TC; no baud timing is simulated.
        self.edges = {1: [], 2: [], 'heartbeat': []}
        self.serial = bytearray()
        self.serial_ticks = []
        self.pending = False
        self.active = 0
        self.action = None
        self.switches = 0
        self.instruction_count = 0
        self.uc.hook_add(UC_HOOK_CODE, self.code)
        # Restrict MMIO hooks to peripherals. Unicorn 2.1.4 has an IT-state
        # issue if a global memory hook instruments conditional LDM/STM in
        # ARMCC's scatter-loader; ordinary RAM needs no callbacks here.
        self.uc.hook_add(UC_HOOK_MEM_READ, self.read, begin=RCC, end=RCC + 7)
        self.uc.hook_add(UC_HOOK_MEM_WRITE, self.write,
                         begin=0x40000000, end=0x4002FFFF)
        self.uc.hook_add(UC_HOOK_MEM_WRITE, self.write, begin=ICSR, end=ICSR + 3)
        self.uc.reg_write(UC_ARM_REG_MSP, self.read32(0x08000000))
        self.uc.reg_write(UC_ARM_REG_XPSR, 1 << 24)
        self.uc.reg_write(UC_ARM_REG_PC, self.read32(0x08000004))

    def read32(self, address):
        return struct.unpack('<I', self.uc.mem_read(address, 4))[0]

    def write32(self, address, value):
        self.uc.mem_write(address, struct.pack('<I', value))

    def variable(self, name):
        return self.read32(self.symbols[name])

    def read(self, uc, access, address, size, value, user):
        if address == RCC:
            cr = self.read32(RCC) & ~((1 << 17) | (1 << 25))
            if cr & (1 << 16) and self.hse:
                cr |= 1 << 17
            if cr & (1 << 24):
                cr |= 1 << 25
            self.write32(RCC, cr | 2)
        elif address == RCC + 4:
            cfgr = self.read32(RCC + 4)
            self.write32(RCC + 4, (cfgr & ~12) | ((cfgr & 3) << 2))

    def write(self, uc, access, address, size, value, user):
        if address == ICSR:
            if value & (1 << 27):
                self.pending = False
            if value & (1 << 28):
                self.pending = True
        elif address in (0x40011010, 0x40010C10):
            # Only log application edges once OSRunning is true.
            if uc.mem_read(self.symbols['OSRunning'], 1) == b'\x01':
                pins = [('heartbeat', 13)] if address == 0x40011010 else [(1, 0), (2, 1)]
                for led, pin in pins:
                    if value & ((1 << pin) | (1 << (pin + 16))):
                        on = bool(value & (1 << (pin + 16)))  # active low
                        self.edges[led].append([self.variable('OSTime'), on])
        elif address == UART + 4:
            if not self.serial or self.serial[-1] == 10:
                self.serial_ticks.append(self.variable('OSTime'))
            self.serial.append(value & 255)

    def code(self, uc, address, size, user):
        self.instruction_count += 1
        if self.pending and not self.active and not uc.reg_read(UC_ARM_REG_PRIMASK):
            self.action = 'pendsv'
            uc.emu_stop()
            return
        opcode = bytes(uc.mem_read(address, 2))
        if self.active and opcode == b'\x70\x47' and uc.reg_read(UC_ARM_REG_LR) >= 0xFFFFFFF0:
            self.action = 'return'
            uc.emu_stop()
        elif opcode == b'\x30\xbf':  # WFI in OSTaskIdleHook
            self.action = 'idle'
            uc.reg_write(UC_ARM_REG_PC, address + 2)
            uc.emu_stop()
        elif address == (self.symbols['Board_Fatal'] & ~1):
            raise AssertionError(f"Board_Fatal called: {uc.reg_read(UC_ARM_REG_R0):#x}")

    def enter(self, exception):
        assert not self.active
        uc = self.uc
        use_psp = bool(uc.reg_read(UC_ARM_REG_CONTROL) & 2)
        stack_reg = UC_ARM_REG_PSP if use_psp else UC_ARM_REG_MSP
        sp = uc.reg_read(stack_reg)
        assert sp % 8 == 0, f'Exception entry stack is not aligned: {sp:#x}'
        frame = [uc.reg_read(reg) for reg in REGS]
        frame[6] &= ~1
        uc.mem_write(sp - 32, struct.pack('<8I', *frame))
        uc.reg_write(stack_reg, sp - 32)
        uc.reg_write(UC_ARM_REG_XPSR, (1 << 24) | exception)
        uc.reg_write(UC_ARM_REG_LR, 0xFFFFFFFD if use_psp else 0xFFFFFFF9)
        uc.reg_write(UC_ARM_REG_PC, self.read32(0x08000000 + exception * 4))
        self.active = exception
        if exception == 14:
            self.pending = False
            self.switches += 1

    def leave(self):
        uc = self.uc
        use_psp = bool(uc.reg_read(UC_ARM_REG_LR) & 4)
        stack_reg = UC_ARM_REG_PSP if use_psp else UC_ARM_REG_MSP
        sp = uc.reg_read(stack_reg)
        frame = struct.unpack('<8I', uc.mem_read(sp, 32))
        uc.reg_write(UC_ARM_REG_XPSR, frame[7])
        uc.reg_write(UC_ARM_REG_CONTROL, 2 if use_psp else 0)
        uc.reg_write(stack_reg, sp + 32)
        for reg, value in zip(REGS[:6], frame[:6]):
            uc.reg_write(reg, value)
        uc.reg_write(UC_ARM_REG_PC, frame[6] | 1)
        self.active = 0

    def run(self, ticks):
        limit = 25000000
        while self.instruction_count < limit:
            self.action = None
            self.uc.emu_start(self.uc.reg_read(UC_ARM_REG_PC) | 1,
                              0, count=1000000)
            if self.action == 'pendsv':
                self.enter(14)
            elif self.action == 'return':
                self.leave()
            elif self.action == 'idle':
                if self.variable('OSTime') >= ticks:
                    break
                assert self.read32(SYSTICK) == 7
                self.enter(15)
            else:
                raise AssertionError('No expected event within instruction budget')
        else:
            raise AssertionError('Firmware instruction budget exhausted')
        expected_line = 'hello uc/OS! 欢迎来到RTOS多任务环境！\r\n'.encode('gbk')
        assert bytes(self.serial) == expected_line * (ticks // 200)
        assert self.serial_ticks == list(range(200, ticks + 1, 200))
        for led, step in [(1, 100), (2, 300), ('heartbeat', 100)]:
            expected = [[t, i % 2 == 0] for i, t in enumerate(range(0, ticks + 1, step))]
            assert self.edges[led] == expected, (led, self.edges[led])
        assert self.variable('g_fault_code') == 0
        assert self.uc.mem_read(self.symbols['OSTaskCtr'], 1) == b'\x05'
        # Check clock gates and push-pull modes for PB0/PB1 and PC13.
        assert self.read32(RCC + 0x18) & 0x1C == 0x1C
        assert self.read32(0x40010C00) & 0xFF == 0x22
        assert (self.read32(0x40011004) >> 20) & 0xF == 2
        expected_clock = 72000000 if self.hse else 8000000
        assert self.variable('g_board_clock_hz') == expected_clock
        assert self.read32(SYSTICK + 4) == expected_clock // 100 - 1
        assert self.read32(UART + 8) == (expected_clock + 57600) // 115200
        return {
            'result': 'PASS', 'model': 'ARM instructions + modeled MMIO/exception entry and return',
            'hse_available': self.hse, 'clock_hz': expected_clock,
            'simulated_seconds': ticks / 100, 'task_count_including_idle': 5,
            'led1_edges': self.edges[1], 'led2_edges': self.edges[2],
            'heartbeat_edges': self.edges['heartbeat'],
            'pin_mapping': {'led1': 'PB0', 'led2': 'PB1', 'heartbeat': 'PC13'},
            'uart_send_ticks': self.serial_ticks,
            'uart_line_gbk': expected_line.decode('gbk').rstrip(),
            'pendsv_count': self.switches, 'executed_instructions': self.instruction_count,
            'limitations': 'Not cycle-accurate; idle-injected ticks; UART always ready; no physical hardware validation.'
        }


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--no-hse', action='store_true')
    parser.add_argument('--ticks', type=int, default=1200)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = FirmwareCheck(hse=not args.no_hse).run(args.ticks)
    content = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(content + '\n', encoding='utf-8')
    print(content)
