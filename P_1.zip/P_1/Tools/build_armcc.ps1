param([string]$KeilBin = 'D:\Keil MDK\Keil5 MDK 0\ARM\ARMCC\Bin')
$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path $PSScriptRoot -Parent
Push-Location $taskRoot
try {
    [xml]$project = Get-Content '.\P_1.uvprojx' -Raw -Encoding UTF8
    $target = $project.Project.Targets.Target
    $buildOutput = Join-Path $taskRoot 'Objects'
    New-Item -ItemType Directory -Path $buildOutput -Force | Out-Null
    $compilerArgs = @('--cpu','Cortex-M3','--c99','--apcs=interwork','-O2','-Ospace','--split_sections','-g','-DSTM32F10X_MD')
    foreach ($include in $target.TargetOption.TargetArmAds.Cads.VariousControls.IncludePath.Split(';')) {
        $compilerArgs += '-I' + $include
    }
    $objects = @()
    foreach ($group in $target.Groups.Group) {
        foreach ($file in $group.Files.File) {
            $path = [string]$file.FilePath
            $object = Join-Path $buildOutput ([IO.Path]::GetFileNameWithoutExtension($path) + '.o')
            Write-Output "Compiling $path"
            if ($file.FileType -eq '2') {
                & "$KeilBin\armasm.exe" --cpu Cortex-M3 --apcs=interwork -g -o $object $path
            } else {
                & "$KeilBin\armcc.exe" @compilerArgs -c $path -o $object
            }
            if ($LASTEXITCODE -ne 0) { throw "Compile failed: $path" }
            $objects += $object
        }
    }
    & "$KeilBin\armlink.exe" @objects --scatter 'MDK-ARM\P_1.sct' --map --symbols --info sizes,totals,unused --list 'Objects\P_1.map' --output 'Objects\P_1.axf'
    if ($LASTEXITCODE -ne 0) { throw 'Link failed' }
    & "$KeilBin\fromelf.exe" --i32combined --output 'Objects\P_1.hex' 'Objects\P_1.axf'
    if ($LASTEXITCODE -ne 0) { throw 'HEX conversion failed' }
    & "$KeilBin\fromelf.exe" --bin --output 'Objects\P_1.bin' 'Objects\P_1.axf'
    if ($LASTEXITCODE -ne 0) { throw 'BIN conversion failed' }
    Get-Item 'Objects\P_1.axf','Objects\P_1.hex','Objects\P_1.bin' | Select-Object Name,Length
    Write-Output 'BUILD OK'
} finally { Pop-Location }
