#ifndef BOARD_H
#define BOARD_H
#include "stm32f10x.h"

/* PC13 is the Blue Pill heartbeat; LED1/LED2 are on PB0/PB1.
 * All active low: 3.3V -> 330 ohm -> LED anode; cathode -> GPIO.
 * Change the port AND RCC clock bit together for a different board. */
#define BOARD_LED1_PORT          GPIOB
#define BOARD_LED1_PIN           0u
#define BOARD_LED1_CLOCK         RCC_APB2ENR_IOPBEN
#define BOARD_LED1_ACTIVE_LOW    1u
#define BOARD_LED2_PORT          GPIOB
#define BOARD_LED2_PIN           1u
#define BOARD_LED2_CLOCK         RCC_APB2ENR_IOPBEN
#define BOARD_LED2_ACTIVE_LOW    1u
#define BOARD_HEARTBEAT_PORT     GPIOC
#define BOARD_HEARTBEAT_PIN      13u
#define BOARD_HEARTBEAT_CLOCK    RCC_APB2ENR_IOPCEN
#define BOARD_HEARTBEAT_ACTIVE_LOW 1u
#define BOARD_UART_BAUD          115200u

extern volatile uint32_t g_board_clock_hz;
void Board_Init(void);
void Board_StartTick(void);
void Board_SetLED(unsigned int led, unsigned int on);
void Board_SetHeartbeat(unsigned int on);
void Board_SendString(const char *s);
void Board_Fatal(uint32_t code);
#endif
