#include "board.h"
#include "ucos_ii.h"

volatile uint32_t g_board_clock_hz;
volatile uint32_t g_fault_code;

static void GPIO_Mode(GPIO_TypeDef *port, uint32_t pin, uint32_t nibble)
{
    volatile uint32_t *cr = (pin < 8u) ? &port->CRL : &port->CRH;
    uint32_t shift = (pin & 7u) * 4u;
    *cr = (*cr & ~(15u << shift)) | (nibble << shift);
}

void Board_SetLED(unsigned int led, unsigned int on)
{
    GPIO_TypeDef *port = led == 1u ? BOARD_LED1_PORT : BOARD_LED2_PORT;
    uint32_t pin = led == 1u ? BOARD_LED1_PIN : BOARD_LED2_PIN;
    uint32_t low = led == 1u ? BOARD_LED1_ACTIVE_LOW : BOARD_LED2_ACTIVE_LOW;
    /* BSRR atomically changes one pin, avoiding an ODR read/modify/write. */
    port->BSRR = (1u << pin) << ((on ^ low) ? 0u : 16u);
}

void Board_SetHeartbeat(unsigned int on)
{
    BOARD_HEARTBEAT_PORT->BSRR = (1u << BOARD_HEARTBEAT_PIN) <<
        ((on ^ BOARD_HEARTBEAT_ACTIVE_LOW) ? 0u : 16u);
}

void Board_Init(void)
{
    uint32_t pclk2;
    uint32_t divider;
    /* ST SystemInit attempts HSE8/PLL72; detect HSI fallback as well. */
    SystemCoreClockUpdate();
    g_board_clock_hz = SystemCoreClock;
    RCC->APB2ENR |= BOARD_LED1_CLOCK | BOARD_LED2_CLOCK | BOARD_HEARTBEAT_CLOCK |
                    RCC_APB2ENR_IOPAEN | RCC_APB2ENR_USART1EN;
    Board_SetLED(1u, 0u);
    Board_SetLED(2u, 0u);
    Board_SetHeartbeat(0u);
    GPIO_Mode(BOARD_LED1_PORT, BOARD_LED1_PIN, 2u); /* 2 MHz push-pull */
    GPIO_Mode(BOARD_LED2_PORT, BOARD_LED2_PIN, 2u);
    GPIO_Mode(BOARD_HEARTBEAT_PORT, BOARD_HEARTBEAT_PIN, 2u);
    GPIO_Mode(GPIOA, 9u, 0xBu);  /* PA9 USART1_TX: AF push-pull */
    GPIO_Mode(GPIOA, 10u, 4u);   /* PA10 USART1_RX: floating input */
    divider = (RCC->CFGR >> 11) & 7u;
    pclk2 = SystemCoreClock >> ((divider < 4u) ? 0u : (divider - 3u));
    USART1->CR1 = 0u;
    USART1->CR2 = 0u;
    USART1->CR3 = 0u;
    USART1->BRR = (pclk2 + BOARD_UART_BAUD / 2u) / BOARD_UART_BAUD;
    USART1->CR1 = USART_CR1_UE | USART_CR1_TE | USART_CR1_RE;
}

void Board_StartTick(void)
{
    uint32_t reload = SystemCoreClock / OS_TICKS_PER_SEC;
    if ((reload == 0u) || (reload > 0x01000000u)) { Board_Fatal(0xE001u); }
    SysTick->LOAD = reload - 1u;
    SysTick->VAL = 0u;
    /* Set directly: SysTick_Config would overwrite our chosen priority. */
    SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk |
                    SysTick_CTRL_TICKINT_Msk | SysTick_CTRL_ENABLE_Msk;
}

void Board_SendString(const char *s)
{
    while (*s != '\0') {
        while ((USART1->SR & USART_SR_TXE) == 0u) {}
        USART1->DR = (uint8_t)*s++;
    }
    while ((USART1->SR & USART_SR_TC) == 0u) {}
}

void Board_Fatal(uint32_t code)
{
    __disable_irq();
    g_fault_code = code;
    Board_SetLED(1u, 1u);
    Board_SetLED(2u, 1u);
    Board_SetHeartbeat(0u); /* Fatal errors stop the scheduling heartbeat. */
    for (;;) {}
}
