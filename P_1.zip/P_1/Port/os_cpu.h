#ifndef OS_CPU_H
#define OS_CPU_H
/* Educational ARMCC5 Cortex-M3 port; not the upstream Micrium CPU port. */
typedef unsigned char  BOOLEAN;
typedef unsigned char  INT8U;
typedef signed char    INT8S;
typedef unsigned short INT16U;
typedef signed short   INT16S;
typedef unsigned int   INT32U;
typedef signed int     INT32S;
typedef unsigned long long INT64U;
typedef signed long long   INT64S;
typedef float          FP32;
typedef double         FP64;
typedef INT32U         OS_STK;
typedef INT32U         OS_CPU_SR;
#define OS_STK_GROWTH       1u
#define OS_CRITICAL_METHOD  3u
#define OS_CPU_SR_ALLOC()   OS_CPU_SR cpu_sr = 0u
#define OS_ENTER_CRITICAL() do { cpu_sr = OS_CPU_SR_Save(); } while (0)
#define OS_EXIT_CRITICAL()  do { OS_CPU_SR_Restore(cpu_sr); } while (0)
#define OS_TASK_SW()        OSCtxSw()
OS_CPU_SR OS_CPU_SR_Save(void);
void OS_CPU_SR_Restore(OS_CPU_SR sr);
void OSCtxSw(void);
void OSIntCtxSw(void);
void OSStartHighRdy(void);
#endif
