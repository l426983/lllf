; ARMCC5 / armasm Cortex-M3 context switching. No floating point context.
                PRESERVE8
                THUMB
                AREA |.text|, CODE, READONLY
                IMPORT OSTCBCur
                IMPORT OSTCBHighRdy
                IMPORT OSPrioCur
                IMPORT OSPrioHighRdy
                IMPORT OSRunning
                IMPORT __Vectors
                IMPORT OSTaskSwHook
                EXPORT OS_CPU_SR_Save
                EXPORT OS_CPU_SR_Restore
                EXPORT OSCtxSw
                EXPORT OSIntCtxSw
                EXPORT OSStartHighRdy
                EXPORT PendSV_Handler

OS_CPU_SR_Save PROC
                MRS R0, PRIMASK
                CPSID I
                BX LR
                ENDP
OS_CPU_SR_Restore PROC
                MSR PRIMASK, R0
                BX LR
                ENDP
OSCtxSw         PROC
OSIntCtxSw
                LDR R0, =0xE000ED04
                LDR R1, =0x10000000
                STR R1, [R0]
                DSB
                ISB
                BX LR
                ENDP
OSStartHighRdy  PROC
                CPSID I
                MOVS R0, #0
                MSR PSP, R0          ; 0 marks the first switch
                LDR R0, =__Vectors
                LDR R0, [R0]
                MSR MSP, R0          ; OSStart never returns; reclaim boot stack
                LDR R0, =OSRunning
                MOVS R1, #1
                STRB R1, [R0]
                LDR R0, =0xE000ED04
                LDR R1, =0x10000000
                STR R1, [R0]
                DSB
                ISB
                CPSIE I
StartWait       B StartWait
                ENDP
PendSV_Handler  PROC
                CPSID I
                MRS R0, PSP
                CBZ R0, RestoreContext
                STMDB R0!, {R4-R11}
                LDR R1, =OSTCBCur
                LDR R1, [R1]
                STR R0, [R1]         ; OSTCBStkPtr is TCB's first member
RestoreContext
                BL OSTaskSwHook
                LDR R0, =OSPrioHighRdy
                LDRB R1, [R0]
                LDR R0, =OSPrioCur
                STRB R1, [R0]
                LDR R0, =OSTCBHighRdy
                LDR R1, [R0]
                LDR R0, =OSTCBCur
                STR R1, [R0]
                LDR R0, [R1]
                LDMIA R0!, {R4-R11}
                MSR PSP, R0
                LDR LR, =0xFFFFFFFD  ; Thread mode, PSP, basic exception frame
                DSB
                ISB
                CPSIE I
                BX LR
                ENDP
                ALIGN
                END
