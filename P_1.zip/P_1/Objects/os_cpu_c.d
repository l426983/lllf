.\objects\os_cpu_c.o: Port\os_cpu_c.c
.\objects\os_cpu_c.o: .\Middlewares\uCOS-II\Source\ucos_ii.h
.\objects\os_cpu_c.o: .\Config\app_cfg.h
.\objects\os_cpu_c.o: .\Config\os_cfg.h
.\objects\os_cpu_c.o: .\Port\os_cpu.h
.\objects\os_cpu_c.o: .\Middlewares\uCOS-II\Source\os_trace.h
.\objects\os_cpu_c.o: .\Drivers\CMSIS\stm32f10x.h
.\objects\os_cpu_c.o: .\Drivers\CMSIS\core_cm3.h
.\objects\os_cpu_c.o: D:\Keil MDK\Keil5 MDK 0\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\os_cpu_c.o: .\Drivers\CMSIS\system_stm32f10x.h
