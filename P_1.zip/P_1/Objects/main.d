.\objects\main.o: App\main.c
.\objects\main.o: .\Middlewares\uCOS-II\Source\ucos_ii.h
.\objects\main.o: .\Config\app_cfg.h
.\objects\main.o: .\Config\os_cfg.h
.\objects\main.o: .\Port\os_cpu.h
.\objects\main.o: .\Middlewares\uCOS-II\Source\os_trace.h
.\objects\main.o: .\BSP\board.h
.\objects\main.o: .\Drivers\CMSIS\stm32f10x.h
.\objects\main.o: .\Drivers\CMSIS\core_cm3.h
.\objects\main.o: D:\Keil MDK\Keil5 MDK 0\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\main.o: .\Drivers\CMSIS\system_stm32f10x.h
