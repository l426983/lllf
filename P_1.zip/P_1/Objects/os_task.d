.\objects\os_task.o: Middlewares\uCOS-II\Source\os_task.c
.\objects\os_task.o: .\Middlewares\uCOS-II\Source\ucos_ii.h
.\objects\os_task.o: .\Config\app_cfg.h
.\objects\os_task.o: .\Config\os_cfg.h
.\objects\os_task.o: .\Port\os_cpu.h
.\objects\os_task.o: .\Middlewares\uCOS-II\Source\os_trace.h
