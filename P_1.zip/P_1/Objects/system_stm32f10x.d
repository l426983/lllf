.\objects\system_stm32f10x.o: Drivers\CMSIS\system_stm32f10x.c
.\objects\system_stm32f10x.o: Drivers\CMSIS\stm32f10x.h
.\objects\system_stm32f10x.o: Drivers\CMSIS\core_cm3.h
.\objects\system_stm32f10x.o: D:\Keil MDK\Keil5 MDK 0\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\system_stm32f10x.o: Drivers\CMSIS\system_stm32f10x.h
