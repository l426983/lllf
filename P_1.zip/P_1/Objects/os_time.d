.\objects\os_time.o: Middlewares\uCOS-II\Source\os_time.c
.\objects\os_time.o: .\Middlewares\uCOS-II\Source\ucos_ii.h
.\objects\os_time.o: .\Config\app_cfg.h
.\objects\os_time.o: .\Config\os_cfg.h
.\objects\os_time.o: .\Port\os_cpu.h
.\objects\os_time.o: .\Middlewares\uCOS-II\Source\os_trace.h
