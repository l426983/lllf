.\objects\board.o: BSP\board.c
.\objects\board.o: BSP\board.h
.\objects\board.o: .\Drivers\CMSIS\stm32f10x.h
.\objects\board.o: .\Drivers\CMSIS\core_cm3.h
.\objects\board.o: D:\Keil MDK\Keil5 MDK 0\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\board.o: .\Drivers\CMSIS\system_stm32f10x.h
.\objects\board.o: .\Middlewares\uCOS-II\Source\ucos_ii.h
.\objects\board.o: .\Config\app_cfg.h
.\objects\board.o: .\Config\os_cfg.h
.\objects\board.o: .\Port\os_cpu.h
.\objects\board.o: .\Middlewares\uCOS-II\Source\os_trace.h
