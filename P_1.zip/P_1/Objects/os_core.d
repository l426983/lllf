.\objects\os_core.o: Middlewares\uCOS-II\Source\os_core.c
.\objects\os_core.o: .\Middlewares\uCOS-II\Source\ucos_ii.h
.\objects\os_core.o: .\Config\app_cfg.h
.\objects\os_core.o: .\Config\os_cfg.h
.\objects\os_core.o: .\Port\os_cpu.h
.\objects\os_core.o: .\Middlewares\uCOS-II\Source\os_trace.h
