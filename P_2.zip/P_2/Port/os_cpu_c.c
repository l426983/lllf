#include "ucos_ii.h"
#include "stm32f1xx_hal.h"

static void TaskReturned(void)
{
    __disable_irq();
    for (;;) { /* A task must never return. */ }
}

OS_STK *OSTaskStkInit(void (*task)(void *), void *arg,
                     OS_STK *top, INT16U opt)
{
    /* ARM EABI requires 8-byte alignment on exception entry. */
    OS_STK *sp = (OS_STK *)(((INT32U)(top + 1)) & ~7u);
    (void)opt;
    *--sp = 0x01000000u;            /* xPSR: Thumb bit */
    *--sp = ((INT32U)task) & ~1u;   /* hardware-stacked PC */
    *--sp = (INT32U)TaskReturned;   /* LR */
    *--sp = 0x12121212u;            /* R12 */
    *--sp = 0x03030303u;            /* R3 */
    *--sp = 0x02020202u;            /* R2 */
    *--sp = 0x01010101u;            /* R1 */
    *--sp = (INT32U)arg;            /* R0 */
    *--sp = 0x11111111u;            /* R11..R4 saved by PendSV */
    *--sp = 0x10101010u;
    *--sp = 0x09090909u;
    *--sp = 0x08080808u;
    *--sp = 0x07070707u;
    *--sp = 0x06060606u;
    *--sp = 0x05050505u;
    *--sp = 0x04040404u;
    return sp;
}

void OSInitHookBegin(void)
{
    /* No tick interrupt is enabled until LED1 starts in task context. */
    SysTick->CTRL = 0u;
    SCB->ICSR = (1u << 25) | (1u << 27); /* clear pending tick/PendSV */
    NVIC_SetPriorityGrouping(3u);        /* all 4 implemented bits preempt */
    NVIC_SetPriority(PendSV_IRQn, 15u);
    NVIC_SetPriority(SysTick_IRQn, 14u);
}
void OSInitHookEnd(void) {}
void OSTaskCreateHook(OS_TCB *tcb) { (void)tcb; }
void OSTaskDelHook(OS_TCB *tcb) { (void)tcb; }
void OSTCBInitHook(OS_TCB *tcb) { (void)tcb; }
void OSTaskIdleHook(void) { __WFI(); }
void OSTaskStatHook(void) {}
void OSTaskReturnHook(OS_TCB *tcb) { (void)tcb; TaskReturned(); }
void OSTaskSwHook(void) {}

void SysTick_Handler(void)
{
    static uint8_t divider;
    HAL_IncTick();
    if (OSRunning == OS_TRUE) {
        if (++divider == (1000u / OS_TICKS_PER_SEC)) {
            divider = 0u;
            OSIntEnter();
            OSTimeTick();
            OSIntExit();
        }
    } else {
        divider = 0u;
    }
}
