#include "aht20.h"
#include "board.h"
#include "ucos_ii.h"

/* HAL expects the 7-bit address shifted left, for BOTH transmit and receive. */
#define AHT20_ADDRESS (0x38u << 1)
#define I2C_TIMEOUT_MS 25u

static void WaitMs(uint32_t ms)
{
    /* Extra tick guarantees minimum wait even just before a tick boundary. */
    OSTimeDly((ms * OS_TICKS_PER_SEC + 999u) / 1000u + 1u);
}

static AHT20_Result CheckHAL(HAL_StatusTypeDef status)
{
    g_i2c_hal_error = HAL_I2C_GetError(&hi2c1);
    if (status == HAL_OK) { return AHT20_OK; }
    if (g_i2c_hal_error & HAL_I2C_ERROR_AF) { return AHT20_NACK; }
    if (status == HAL_TIMEOUT || (g_i2c_hal_error & HAL_I2C_ERROR_TIMEOUT)) {
        return AHT20_TIMEOUT;
    }
    return AHT20_BUS;
}

static AHT20_Result ReadStatus(uint8_t *status)
{
    /* On wire the read address is 0x71; no EEPROM register address. */
    return CheckHAL(HAL_I2C_Master_Receive(&hi2c1, AHT20_ADDRESS, status,
                                          1u, I2C_TIMEOUT_MS));
}

static uint8_t CRC8(const uint8_t *bytes)
{
    uint8_t crc = 0xFFu;
    unsigned int i, bit;
    for (i = 0u; i < 6u; ++i) {
        crc ^= bytes[i];
        for (bit = 0u; bit < 8u; ++bit) {
            crc = (uint8_t)((crc & 0x80u) ? ((crc << 1) ^ 0x31u) : (crc << 1));
        }
    }
    return crc;
}

AHT20_Result AHT20_Init(void)
{
    uint8_t status;
    uint8_t command[3] = {0xBEu, 0x08u, 0x00u};
    AHT20_Result result;
    WaitMs(100u);
    if (!Board_I2CRecover()) { return AHT20_BUS; }
    result = ReadStatus(&status);
    if (result != AHT20_OK) { return result; }
    if (status & 0x80u) { return AHT20_BUSY; }
    if (!(status & 0x08u)) {
        result = CheckHAL(HAL_I2C_Master_Transmit(&hi2c1, AHT20_ADDRESS,
                           command, sizeof(command), I2C_TIMEOUT_MS));
        if (result != AHT20_OK) { return result; }
        WaitMs(10u);
        result = ReadStatus(&status);
        if (result != AHT20_OK) { return result; }
        if (!(status & 0x08u)) { return AHT20_CALIBRATION; }
    }
    return AHT20_OK;
}

AHT20_Result AHT20_Measure(AHT20_Data *data)
{
    uint8_t command[3] = {0xACu, 0x33u, 0x00u};
    uint8_t frame[7];
    uint8_t status;
    uint32_t raw_humidity, raw_temperature;
    unsigned int retry;
    AHT20_Result result = CheckHAL(HAL_I2C_Master_Transmit(&hi2c1,
        AHT20_ADDRESS, command, sizeof(command), I2C_TIMEOUT_MS));
    if (result != AHT20_OK) { return result; }
    WaitMs(80u);
    for (retry = 0u; retry < 10u; ++retry) {
        result = ReadStatus(&status);
        if (result != AHT20_OK) { return result; }
        if (!(status & 0x80u)) { break; }
        WaitMs(10u);
    }
    if (retry == 10u) { return AHT20_BUSY; }
    result = CheckHAL(HAL_I2C_Master_Receive(&hi2c1, AHT20_ADDRESS,
                                           frame, sizeof(frame), I2C_TIMEOUT_MS));
    if (result != AHT20_OK) { return result; }
    if (frame[0] & 0x80u) { return AHT20_BUSY; }
    if (!(frame[0] & 0x08u)) { return AHT20_CALIBRATION; }
    if (CRC8(frame) != frame[6]) { return AHT20_CRC; }
    raw_humidity = ((uint32_t)frame[1] << 12) | ((uint32_t)frame[2] << 4) |
                   ((uint32_t)frame[3] >> 4);
    raw_temperature = (((uint32_t)frame[3] & 0x0Fu) << 16) |
                      ((uint32_t)frame[4] << 8) | frame[5];
    data->humidity_centi_rh = (uint32_t)(((uint64_t)raw_humidity * 10000u +
                                        524288u) >> 20);
    data->temperature_centi_c = (int32_t)(((uint64_t)raw_temperature * 20000u +
                                          524288u) >> 20) - 5000;
    return AHT20_OK;
}

const char *AHT20_ErrorName(AHT20_Result result)
{
    switch (result) {
    case AHT20_OK: return "OK";
    case AHT20_BUS: return "BUS";
    case AHT20_NACK: return "NACK";
    case AHT20_TIMEOUT: return "TIMEOUT";
    case AHT20_BUSY: return "BUSY";
    case AHT20_CALIBRATION: return "CALIBRATION";
    case AHT20_CRC: return "CRC";
    default: return "UNKNOWN";
    }
}
