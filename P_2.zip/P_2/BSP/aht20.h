#ifndef AHT20_H
#define AHT20_H
#include <stdint.h>
/* AHT20 product manual V1.2, sections 5.4 and 6. */
typedef enum {
    AHT20_OK = 0, AHT20_BUS = 1, AHT20_NACK = 2, AHT20_TIMEOUT = 3,
    AHT20_BUSY = 4, AHT20_CALIBRATION = 5, AHT20_CRC = 6
} AHT20_Result;
typedef struct {
    int32_t temperature_centi_c;
    uint32_t humidity_centi_rh;
} AHT20_Data;
/* Call from task context after OSStart; these functions use OSTimeDly. */
AHT20_Result AHT20_Init(void);
AHT20_Result AHT20_Measure(AHT20_Data *data);
const char *AHT20_ErrorName(AHT20_Result result);
#endif
