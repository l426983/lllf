#include "board.h"
#include "ucos_ii.h"

I2C_HandleTypeDef hi2c1;
UART_HandleTypeDef huart1;
volatile uint32_t g_board_clock_hz;
volatile uint32_t g_fault_code;
volatile uint32_t g_i2c_hal_error;

static void Clock_Config(void)
{
    RCC_OscInitTypeDef osc = {0};
    RCC_ClkInitTypeDef clk = {0};
    osc.OscillatorType = RCC_OSCILLATORTYPE_HSE | RCC_OSCILLATORTYPE_HSI;
    osc.HSEState = RCC_HSE_ON;
    osc.HSIState = RCC_HSI_ON;
    osc.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    osc.PLL.PLLState = RCC_PLL_ON;
    osc.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    osc.PLL.PLLMUL = RCC_PLL_MUL9;
    clk.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK |
                    RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    clk.AHBCLKDivider = RCC_SYSCLK_DIV1;
    clk.APB2CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_OscConfig(&osc) == HAL_OK) {
        clk.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
        clk.APB1CLKDivider = RCC_HCLK_DIV2;
        if (HAL_RCC_ClockConfig(&clk, FLASH_LATENCY_2) != HAL_OK) {
            Board_Fatal(0xC001u);
        }
    } else {
        clk.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
        clk.APB1CLKDivider = RCC_HCLK_DIV1;
        if (HAL_RCC_ClockConfig(&clk, FLASH_LATENCY_0) != HAL_OK) {
            Board_Fatal(0xC002u);
        }
        osc.OscillatorType = RCC_OSCILLATORTYPE_HSE;
        osc.HSEState = RCC_HSE_OFF;
        osc.PLL.PLLState = RCC_PLL_OFF;
        (void)HAL_RCC_OscConfig(&osc);
    }
    g_board_clock_hz = HAL_RCC_GetHCLKFreq();
}

void Board_SetLED(unsigned int led, unsigned int on)
{
    HAL_GPIO_WritePin(GPIOB, led == 1u ? GPIO_PIN_0 : GPIO_PIN_1,
                      on ? GPIO_PIN_RESET : GPIO_PIN_SET);
}

void Board_DelayUs(uint32_t us)
{
    uint32_t start = DWT->CYCCNT;
    uint32_t cycles = us * (g_board_clock_hz / 1000000u);
    while ((uint32_t)(DWT->CYCCNT - start) < cycles) {}
}

void Board_Init(void)
{
    GPIO_InitTypeDef gpio = {0};
    if (HAL_Init() != HAL_OK) { Board_Fatal(0xC003u); }
    Clock_Config();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_AFIO_CLK_ENABLE();
    __HAL_AFIO_REMAP_SWJ_NOJTAG(); /* Keep PA13/PA14 SWD available. */
    Board_SetLED(1u, 0u);
    Board_SetLED(2u, 0u);
    gpio.Pin = GPIO_PIN_0 | GPIO_PIN_1;
    gpio.Mode = GPIO_MODE_OUTPUT_PP;
    gpio.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOB, &gpio);
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0u;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
    huart1.Instance = USART1;
    huart1.Init.BaudRate = BOARD_UART_BAUD;
    huart1.Init.WordLength = UART_WORDLENGTH_8B;
    huart1.Init.StopBits = UART_STOPBITS_1;
    huart1.Init.Parity = UART_PARITY_NONE;
    huart1.Init.Mode = UART_MODE_TX_RX;
    huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK) { Board_Fatal(0xC004u); }
}

void HAL_UART_MspInit(UART_HandleTypeDef *uart)
{
    GPIO_InitTypeDef gpio = {0};
    if (uart->Instance != USART1) { return; }
    __HAL_RCC_USART1_CLK_ENABLE();
    gpio.Pin = GPIO_PIN_9;
    gpio.Mode = GPIO_MODE_AF_PP;
    gpio.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &gpio);
    gpio.Pin = GPIO_PIN_10;
    gpio.Mode = GPIO_MODE_INPUT;
    gpio.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &gpio);
}

void HAL_I2C_MspInit(I2C_HandleTypeDef *i2c)
{
    GPIO_InitTypeDef gpio = {0};
    if (i2c->Instance != I2C1) { return; }
    __HAL_RCC_I2C1_CLK_ENABLE();
    __HAL_AFIO_REMAP_I2C1_DISABLE();
    gpio.Pin = GPIO_PIN_6 | GPIO_PIN_7;
    gpio.Mode = GPIO_MODE_AF_OD;
    gpio.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOB, &gpio);
}

static int SCL_High(void)
{
    uint32_t start;
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
    start = DWT->CYCCNT;
    while (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_6) == GPIO_PIN_RESET) {
        if ((uint32_t)(DWT->CYCCNT - start) >= g_board_clock_hz / 1000u) {
            return 0;
        }
    }
    Board_DelayUs(5u);
    return 1;
}

int Board_I2CRecover(void)
{
    GPIO_InitTypeDef gpio = {0};
    unsigned int i;
    __HAL_RCC_I2C1_CLK_ENABLE();
    __HAL_RCC_I2C1_FORCE_RESET();
    __HAL_RCC_I2C1_RELEASE_RESET();
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6 | GPIO_PIN_7, GPIO_PIN_SET);
    gpio.Pin = GPIO_PIN_6 | GPIO_PIN_7;
    gpio.Mode = GPIO_MODE_OUTPUT_OD;
    gpio.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOB, &gpio);
    if (!SCL_High()) { return 0; }
    for (i = 0u; i < 9u && HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_7) == GPIO_PIN_RESET; ++i) {
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);
        Board_DelayUs(5u);
        if (!SCL_High()) { return 0; }
    }
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
    Board_DelayUs(5u);
    if (!SCL_High()) { return 0; }
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
    Board_DelayUs(5u);
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_7) == GPIO_PIN_RESET) { return 0; }
    hi2c1.Instance = I2C1;
    hi2c1.State = HAL_I2C_STATE_RESET;
    hi2c1.Lock = HAL_UNLOCKED;
    hi2c1.Init.ClockSpeed = 100000u;
    hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
    hi2c1.Init.OwnAddress1 = 0u;
    hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
    hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
    hi2c1.Init.OwnAddress2 = 0u;
    hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
    hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
    return HAL_I2C_Init(&hi2c1) == HAL_OK;
}

void Board_StartTick(void)
{
    /* HAL stays at 1 ms; the port divides ten SysTicks into one OS tick. */
    if (HAL_InitTick(14u) != HAL_OK) { Board_Fatal(0xE001u); }
}

void Board_SendString(const char *s)
{
    uint16_t length = 0u;
    while (s[length] != '\0') { ++length; }
    if (HAL_UART_Transmit(&huart1, (uint8_t *)s, length, 100u) != HAL_OK) {
        Board_Fatal(0xC005u);
    }
}

void Board_Fatal(uint32_t code)
{
    __disable_irq();
    g_fault_code = code;
    Board_SetLED(1u, 1u);
    Board_SetLED(2u, 1u);
    for (;;) {}
}
