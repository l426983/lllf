#ifndef BOARD_H
#define BOARD_H
#include "stm32f1xx_hal.h"
#define BOARD_UART_BAUD 115200u
extern I2C_HandleTypeDef hi2c1;
extern UART_HandleTypeDef huart1;
extern volatile uint32_t g_board_clock_hz;
extern volatile uint32_t g_i2c_hal_error;
void Board_Init(void);
void Board_StartTick(void);
void Board_DelayUs(uint32_t us);
int Board_I2CRecover(void);
void Board_SetLED(unsigned int led, unsigned int on);
void Board_SendString(const char *s);
void Board_Fatal(uint32_t code);
#endif
