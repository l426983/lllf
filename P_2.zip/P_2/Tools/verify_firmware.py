"""Run the actual ARMCC ELF including ST HAL and uC/OS-II in Unicorn.

I2C register events and AHT20 responses are modeled, not electrical timing.
SysTick is injected at idle or after a bounded instruction count in polling.
Requires unicorn and pyelftools; never accesses a connected physical board.
"""
import argparse
import hashlib
import json
import struct
from pathlib import Path
from unicorn import UC_HOOK_MEM_READ, UC_HOOK_MEM_WRITE
from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_PRIMASK
from kernel_model import FirmwareCheck, RCC, SYSTICK, UART

I2C = 0x40005400
GPIOB = 0x40010C00
DWT = 0xE0001000


def crc8(data):
    crc = 255
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = ((crc << 1) ^ (0x31 if crc & 128 else 0)) & 255
    return crc


class AHTCheck(FirmwareCheck):
    def __init__(self, hse=True, scenario='normal'):
        self.scenario = scenario
        self.next_tick = 5000
        self.cycles = 0
        self.gpio_odr = 0
        self.stage = 'idle'
        self.tx = []
        self.rx = []
        self.rx_index = 0
        self.commands = []
        self.triggers = []
        self.read_lengths = []
        self.addresses = []
        self.calibrated = scenario != 'calibrate'
        self.measure_start = None
        self.ack_disabled = False
        self.stop_seen = False
        super().__init__(hse)
        self.uc.mem_map(0x42000000, 0x600000)  # Cortex-M3 peripheral bit-band
        self.uc.hook_add(UC_HOOK_MEM_READ, self.read, begin=0x42000000, end=0x425FFFFF)
        self.uc.hook_add(UC_HOOK_MEM_WRITE, self.write, begin=0x42000000, end=0x425FFFFF)
        self.uc.mem_map(DWT, 0x1000)
        self.uc.hook_add(UC_HOOK_MEM_READ, self.read, begin=DWT, end=DWT + 7)
        self.uc.hook_add(UC_HOOK_MEM_READ, self.read, begin=I2C, end=I2C + 0x23)
        self.uc.hook_add(UC_HOOK_MEM_READ, self.read, begin=GPIOB + 8, end=GPIOB + 11)

    def status(self):
        busy = self.measure_start is not None and (
            self.scenario == 'busy' or self.variable('OSTime') - self.measure_start < 8)
        return (8 if self.calibrated else 0) | (128 if busy else 0)

    def frame(self):
        # Independent raw test vectors: 25 C / 50 % and -10 C / 100 %.
        rh, temp = (0xFFFFF, 209715) if self.scenario == 'negative' else (524288, 393216)
        packed = (rh << 20) | temp
        data = [self.status()] + list(packed.to_bytes(5, 'big'))
        data.append(crc8(data) ^ (1 if self.scenario == 'crc' else 0))
        return data

    def read(self, uc, access, address, size, value, user):
        super().read(uc, access, address, size, value, user)
        if 0x42000000 <= address < 0x42600000:
            offset = address - 0x42000000
            byte_addr = 0x40000000 + offset // 32
            self.write32(address, (uc.mem_read(byte_addr, 1)[0] >> ((offset % 32) // 4)) & 1)
        elif address == DWT + 4:
            self.cycles = (self.cycles + 1000) & 0xFFFFFFFF
            self.write32(address, self.cycles)
        elif address == GPIOB + 8:
            pins = self.gpio_odr & 0xC0
            if self.scenario == 'scl_stuck':
                pins &= ~0x40
            if self.scenario == 'sda_stuck':
                pins &= ~0x80
            self.write32(address, pins)
        elif address == I2C:
            # START/STOP are hardware cleared after events have occurred.
            self.write32(address, self.read32(address) & ~0x300)
        elif address == I2C + 0x14:
            if self.stage == 'start':
                sr1 = 1
            elif self.stage == 'address':
                sr1 = 0x400 if self.scenario == 'nack' else 2
                if self.scenario == 'timeout':
                    sr1 = 0
            elif self.stage == 'tx':
                sr1 = 0x84
            elif self.stage == 'rx':
                sr1 = 0x44
            else:
                sr1 = 0
            self.write32(address, sr1)
        elif address == I2C + 0x18:
            self.write32(address, 0)  # BUSY clear between transactions.
            if self.stage == 'address' and self.scenario not in ('nack', 'timeout'):
                self.stage = 'rx' if self.addresses[-1] & 1 else 'tx'
        elif address == I2C + 0x10 and self.stage == 'rx':
            if self.rx_index == 0:
                # First byte is status; payload follows only for 7-byte reads.
                self.rx = self.frame()
            assert self.rx_index < 7, 'Unexpected extra AHT20 data read'
            self.write32(address, self.rx[self.rx_index])
            self.rx_index += 1

    def finish_read(self):
        if not self.rx_index:
            return
        assert self.rx_index in (1, 7), self.rx_index
        assert self.ack_disabled and self.stop_seen, 'Read ended without NACK/STOP'
        self.read_lengths.append(self.rx_index)
        self.rx_index = 0

    def write(self, uc, access, address, size, value, user):
        super().write(uc, access, address, size, value, user)
        if 0x42000000 <= address < 0x42600000:
            offset = address - 0x42000000
            byte_addr = 0x40000000 + offset // 32
            mask = 1 << ((offset % 32) // 4)
            old = uc.mem_read(byte_addr, 1)[0]
            uc.mem_write(byte_addr, bytes([(old | mask) if value else (old & ~mask)]))
        elif address == GPIOB + 0x10:
            self.gpio_odr = (self.gpio_odr | (value & 65535)) & ~(value >> 16)
        elif address == I2C:
            if self.stage in ('address', 'rx') and not value & 0x400:
                self.ack_disabled = True
            if value & 0x100:
                self.finish_read()
                self.stage = 'start'
                self.tx = []
                self.ack_disabled = False
                self.stop_seen = False
            if value & 0x200:
                self.stop_seen = True
                if self.stage == 'tx':
                    self.commands.append(self.tx[:])
                    if self.tx == [0xBE, 8, 0]:
                        self.calibrated = True
                    elif self.tx == [0xAC, 0x33, 0]:
                        self.measure_start = self.variable('OSTime')
                        self.triggers.append(self.measure_start)
                    else:
                        raise AssertionError(f'Unexpected command: {self.tx}')
                    self.stage = 'idle'
        elif address == I2C + 0x10:
            if self.stage == 'start':
                assert value in (0x70, 0x71), hex(value)
                self.addresses.append(value)
                self.stage = 'address'
            elif self.stage == 'tx':
                self.tx.append(value & 255)

    def code(self, uc, address, size, user):
        super().code(uc, address, size, user)
        if self.action:
            return
        if (self.instruction_count >= self.next_tick and not self.active
                and not uc.reg_read(UC_ARM_REG_PRIMASK) and self.read32(SYSTICK) & 1):
            self.action = 'tick'
            uc.emu_stop()

    def enter(self, exception):
        if exception == 15:
            self.next_tick = self.instruction_count + 5000
        super().enter(exception)

    def run(self, ticks=1230):
        while self.instruction_count < 30000000:
            self.action = None
            self.uc.emu_start(self.uc.reg_read(UC_ARM_REG_PC) | 1, 0, count=1000000)
            if self.action == 'pendsv':
                self.enter(14)
            elif self.action == 'return':
                self.leave()
            elif self.action in ('idle', 'tick'):
                if self.variable('OSTime') >= ticks and self.action == 'idle':
                    break
                assert self.read32(SYSTICK) == 7
                self.enter(15)
            else:
                raise AssertionError(f'Unexpected stop, PC={self.uc.reg_read(UC_ARM_REG_PC):#x}')
        else:
            raise AssertionError('Instruction budget exhausted')
        self.finish_read()
        return self.validate(ticks)

    def validate(self, ticks):
        lines = self.serial.decode('ascii').splitlines()
        count = ticks // 200
        assert len(lines) == count, lines
        expected_error = {'crc': 'CRC', 'busy': 'BUSY', 'nack': 'NACK',
                          'timeout': 'TIMEOUT', 'scl_stuck': 'BUS', 'sda_stuck': 'BUS'}.get(self.scenario)
        expected_values = 'T=-10.00 C, RH=100.00 %' if self.scenario == 'negative' else 'T=25.00 C, RH=50.00 %'
        for index, line in enumerate(lines, 1):
            suffix = 'ERROR=' + expected_error if expected_error else expected_values
            assert line == f't={index * 2000}ms AHT20 {suffix}', line
        if not expected_error:
            assert self.variable('g_sensor_samples') == count
            assert self.variable('g_sensor_errors') == 0
            assert self.triggers == list(range(200, ticks + 1, 200)), self.triggers
            assert all(t >= start + 8 for t, start in zip(self.serial_ticks, self.triggers))
        else:
            assert self.variable('g_sensor_samples') == 0
            assert self.variable('g_sensor_errors') == count
        if self.scenario == 'calibrate':
            assert self.commands[0] == [0xBE, 8, 0]
        for led, step in [(1, 100), (2, 300)]:
            expected = [[t, i % 2 == 0] for i, t in enumerate(range(0, ticks + 1, step))]
            assert self.edges[led] == expected, (led, self.edges[led])
        assert self.variable('g_fault_code') == 0
        assert self.uc.mem_read(self.symbols['OSTaskCtr'], 1) == b'\x04'
        assert self.pc13_writes == 0
        assert not self.read32(RCC + 0x18) & (1 << 4)  # GPIOC clock unused
        for stack in ('s_led1_stack', 's_led2_stack', 's_uart_stack'):
            assert bytes(self.uc.mem_read(self.symbols[stack], 64)) == bytes(64), stack
        clock = 72000000 if self.hse else 8000000
        assert self.variable('g_board_clock_hz') == clock
        assert self.read32(SYSTICK + 4) == clock // 1000 - 1
        assert abs(self.read32(UART + 8) - clock / 115200) < 1
        assert self.read32(GPIOB) & 255 == 0x22
        if self.scenario not in ('scl_stuck', 'sda_stuck'):
            assert (self.read32(GPIOB) >> 24) & 255 == 0xFF  # AF open-drain, 50 MHz IO
            pclk1 = clock // 2 if self.hse else clock
            assert self.read32(I2C + 0x1C) & 4095 == pclk1 // 200000
        firmware = Path(__file__).resolve().parents[1] / 'Objects/P_2.axf'
        return {'result': 'PASS', 'scenario': self.scenario, 'clock_hz': clock,
                'firmware_sha256': hashlib.sha256(firmware.read_bytes()).hexdigest(),
                'os_ticks': ticks, 'uart_lines': lines, 'uart_output_ticks': self.serial_ticks,
                'measure_trigger_ticks': self.triggers, 'i2c_commands': self.commands,
                'read_lengths': self.read_lengths, 'task_count_including_idle': 4,
                'led1_edges': self.edges[1], 'led2_edges': self.edges[2],
                'pc13_writes': self.pc13_writes,
                'task_stack_low_64_bytes_untouched': True,
                'executed_instructions': self.instruction_count,
                'limitations': 'Real ARM ELF including ST HAL/kernel; synthetic I2C register events and SysTicks; no electrical, cycle-accurate or physical-board validation.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--no-hse', action='store_true')
    parser.add_argument('--scenario', default='normal', choices=['normal', 'negative', 'calibrate', 'crc', 'busy', 'nack', 'timeout', 'scl_stuck', 'sda_stuck'])
    parser.add_argument('--ticks', type=int, default=1230)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = AHTCheck(not args.no_hse, args.scenario).run(args.ticks)
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(text + '\n', encoding='utf-8')
    print(text)
