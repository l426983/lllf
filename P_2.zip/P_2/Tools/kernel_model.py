"""Execute the real ARM ELF with Unicorn; model only the peripherals we use.

Requires: unicorn, pyelftools. Run after build_armcc.ps1.
The harness supplies Cortex-M exception entry/return; the derived AHT20 model
injects 1 ms SysTicks. This is not a cycle-accurate or physical-board test.
"""
import struct
from pathlib import Path

from elftools.elf.elffile import ELFFile
from unicorn import (Uc, UC_ARCH_ARM, UC_MODE_THUMB, UC_MODE_MCLASS,
                     UC_HOOK_CODE, UC_HOOK_MEM_READ, UC_HOOK_MEM_WRITE)
from unicorn.arm_const import *

ROOT = Path(__file__).resolve().parents[1]
RCC = 0x40021000
UART = 0x40013800
ICSR = 0xE000ED04
SYSTICK = 0xE000E010
REGS = [UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3,
        UC_ARM_REG_R12, UC_ARM_REG_LR, UC_ARM_REG_PC, UC_ARM_REG_XPSR]


class FirmwareCheck:
    def __init__(self, hse=True):
        self.hse = hse
        self.uc = Uc(UC_ARCH_ARM, UC_MODE_THUMB | UC_MODE_MCLASS)
        self.uc.ctl_set_cpu_model(UC_CPU_ARM_CORTEX_M3)
        for address, size in [(0x08000000, 0x10000), (0x20000000, 0x5000),
                              (0x40000000, 0x30000), (0xE000E000, 0x2000)]:
            self.uc.mem_map(address, size)
        self.symbols = {}
        with (ROOT / 'Objects/P_2.axf').open('rb') as src:
            elf = ELFFile(src)
            for segment in elf.iter_segments():
                if segment['p_type'] == 'PT_LOAD' and segment['p_filesz']:
                    # ELF p_paddr includes the ROM load image of RW data.
                    self.uc.mem_write(segment['p_paddr'], segment.data())
            for symbol in elf.get_section_by_name('.symtab').iter_symbols():
                self.symbols[symbol.name] = symbol['st_value']
        self.write32(RCC, 0x83)
        self.write32(UART, 0xC0)  # TXE and TC; no baud timing is simulated.
        self.edges = {1: [], 2: []}
        self.pc13_writes = 0
        self.serial = bytearray()
        self.serial_ticks = []
        self.pending = False
        self.active = 0
        self.action = None
        self.switches = 0
        self.instruction_count = 0
        self.uc.hook_add(UC_HOOK_CODE, self.code)
        # Restrict MMIO hooks to peripherals. Unicorn 2.1.4 has an IT-state
        # issue if a global memory hook instruments conditional LDM/STM in
        # ARMCC's scatter-loader; ordinary RAM needs no callbacks here.
        self.uc.hook_add(UC_HOOK_MEM_READ, self.read, begin=RCC, end=RCC + 7)
        self.uc.hook_add(UC_HOOK_MEM_WRITE, self.write,
                         begin=0x40000000, end=0x4002FFFF)
        self.uc.hook_add(UC_HOOK_MEM_WRITE, self.write, begin=ICSR, end=ICSR + 3)
        self.uc.reg_write(UC_ARM_REG_MSP, self.read32(0x08000000))
        self.uc.reg_write(UC_ARM_REG_XPSR, 1 << 24)
        self.uc.reg_write(UC_ARM_REG_PC, self.read32(0x08000004))

    def read32(self, address):
        return struct.unpack('<I', self.uc.mem_read(address, 4))[0]

    def write32(self, address, value):
        self.uc.mem_write(address, struct.pack('<I', value))

    def variable(self, name):
        return self.read32(self.symbols[name])

    def read(self, uc, access, address, size, value, user):
        if address == RCC:
            cr = self.read32(RCC) & ~((1 << 17) | (1 << 25))
            if cr & (1 << 16) and self.hse:
                cr |= 1 << 17
            if cr & (1 << 24):
                cr |= 1 << 25
            self.write32(RCC, cr | 2)
        elif address == RCC + 4:
            cfgr = self.read32(RCC + 4)
            self.write32(RCC + 4, (cfgr & ~12) | ((cfgr & 3) << 2))

    def write(self, uc, access, address, size, value, user):
        if address == ICSR:
            if value & (1 << 27):
                self.pending = False
            if value & (1 << 28):
                self.pending = True
        elif address in (0x40011010, 0x40010C10):
            if address == 0x40011010 and value & ((1 << 13) | (1 << 29)):
                self.pc13_writes += 1
            # Only log application edges once OSRunning is true.
            if uc.mem_read(self.symbols['OSRunning'], 1) == b'\x01':
                pins = [] if address == 0x40011010 else [(1, 0), (2, 1)]
                for led, pin in pins:
                    if value & ((1 << pin) | (1 << (pin + 16))):
                        on = bool(value & (1 << (pin + 16)))  # active low
                        self.edges[led].append([self.variable('OSTime'), on])
        elif address == UART + 4:
            if not self.serial or self.serial[-1] == 10:
                self.serial_ticks.append(self.variable('OSTime'))
            self.serial.append(value & 255)

    def code(self, uc, address, size, user):
        self.instruction_count += 1
        if self.pending and not self.active and not uc.reg_read(UC_ARM_REG_PRIMASK):
            self.action = 'pendsv'
            uc.emu_stop()
            return
        opcode = bytes(uc.mem_read(address, 2))
        # ARMCC non-leaf ISRs return with POP {...,PC}, whereas the assembly
        # PendSV port uses BX LR. Intercept EXC_RETURN before Unicorn branches
        # to the reserved address; execute the software POP, then unstack the
        # hardware exception frame in leave(). Do not skip any ISR body.
        half = int.from_bytes(opcode, 'little')
        regs = None
        width = 2
        if self.active and (half & 0xFF00) == 0xBD00:
            regs = [i for i in range(8) if half & (1 << i)]
        elif self.active and half == 0xE8BD:
            mask = int.from_bytes(uc.mem_read(address + 2, 2), 'little')
            if mask & 0x8000:
                regs = [i for i in range(15) if mask & (1 << i)]
                width = 4
        if regs is not None:
            sp = uc.reg_read(UC_ARM_REG_SP)
            target = self.read32(sp + 4 * len(regs))
            if target in (0xFFFFFFF1, 0xFFFFFFF9, 0xFFFFFFFD):
                general = [UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2,
                           UC_ARM_REG_R3, UC_ARM_REG_R4, UC_ARM_REG_R5,
                           UC_ARM_REG_R6, UC_ARM_REG_R7, UC_ARM_REG_R8,
                           UC_ARM_REG_R9, UC_ARM_REG_R10, UC_ARM_REG_R11,
                           UC_ARM_REG_R12, UC_ARM_REG_SP, UC_ARM_REG_LR]
                for n, reg in enumerate(regs):
                    uc.reg_write(general[reg], self.read32(sp + 4 * n))
                uc.reg_write(UC_ARM_REG_SP, sp + 4 * (len(regs) + 1))
                uc.reg_write(UC_ARM_REG_LR, target)
                uc.reg_write(UC_ARM_REG_PC, address + width)
                self.action = 'return'
                uc.emu_stop()
                return
        if self.active and opcode == b'\x70\x47' and uc.reg_read(UC_ARM_REG_LR) >= 0xFFFFFFF0:
            self.action = 'return'
            uc.emu_stop()
        elif opcode == b'\x30\xbf':  # WFI in OSTaskIdleHook
            self.action = 'idle'
            uc.reg_write(UC_ARM_REG_PC, address + 2)
            uc.emu_stop()
        elif address == (self.symbols['Board_Fatal'] & ~1):
            raise AssertionError(f"Board_Fatal called: {uc.reg_read(UC_ARM_REG_R0):#x}")

    def enter(self, exception):
        assert not self.active
        uc = self.uc
        use_psp = bool(uc.reg_read(UC_ARM_REG_CONTROL) & 2)
        stack_reg = UC_ARM_REG_PSP if use_psp else UC_ARM_REG_MSP
        sp = uc.reg_read(stack_reg)
        assert sp % 8 == 0, f'Exception entry stack is not aligned: {sp:#x}'
        frame = [uc.reg_read(reg) for reg in REGS]
        frame[6] &= ~1
        uc.mem_write(sp - 32, struct.pack('<8I', *frame))
        uc.reg_write(stack_reg, sp - 32)
        uc.reg_write(UC_ARM_REG_XPSR, (1 << 24) | exception)
        uc.reg_write(UC_ARM_REG_LR, 0xFFFFFFFD if use_psp else 0xFFFFFFF9)
        uc.reg_write(UC_ARM_REG_PC, self.read32(0x08000000 + exception * 4))
        self.active = exception
        if exception == 14:
            self.pending = False
            self.switches += 1

    def leave(self):
        uc = self.uc
        use_psp = bool(uc.reg_read(UC_ARM_REG_LR) & 4)
        stack_reg = UC_ARM_REG_PSP if use_psp else UC_ARM_REG_MSP
        sp = uc.reg_read(stack_reg)
        frame = struct.unpack('<8I', uc.mem_read(sp, 32))
        uc.reg_write(UC_ARM_REG_XPSR, frame[7])
        uc.reg_write(UC_ARM_REG_CONTROL, 2 if use_psp else 0)
        uc.reg_write(stack_reg, sp + 32)
        for reg, value in zip(REGS[:6], frame[:6]):
            uc.reg_write(reg, value)
        uc.reg_write(UC_ARM_REG_PC, frame[6] | 1)
        self.active = 0

