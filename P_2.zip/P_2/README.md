# STM32F103 + AHT20：HAL 硬件 I²C / μC/OS-II 任务二

工程位置：`D:\QR——CSDN\QR_SY_4.0\P_2`

本工程将任务一的串口 hello 任务改为 AHT20 温湿度采集任务，使用 ST 官方 HAL 驱动硬件 I2C1。**PC13 已取消：没有心跳任务，不开启 GPIOC 时钟，不配置或写 PC13。**

## 1. 最终功能

| 应用任务 | 引脚 / 外设 | 行为 | 优先级 |
|---|---|---|---|
| TaskLED1 | PB0，LED1 | 亮 1 s、灭 1 s，完整周期 2 s | 5 |
| TaskLED2 | PB1，LED2 | 亮 3 s、灭 3 s，完整周期 6 s | 6 |
| TaskAHT20 | I2C1 PB6/PB7 + USART1 PA9 | 正常运行时每 2 s 触发采集，完成转换后发送温度、湿度 | 7 |

共 **3 个应用任务**，另有内核空闲任务；μC/OS-II 总任务数为 4。优先级数值越小越高。LED 为低电平点亮。

## 2. 接线

先断电接线。按你提供的四脚模块图：**带孔正面朝自己、四根引脚向下，左到右为 1、2、3、4**。

| AHT20 模块脚 | 名称 | STM32F103 接点 |
|---|---|---|
| 1 | VDD | 3.3V |
| 2 | SDA | PB7 |
| 3 | GND | GND |
| 4 | SCL | PB6 |

手册第 6 页的六焊盘裸器件图不等于此四脚模块的脚位顺序。若实物型号或丝印不同，先核对实际模块定义。

SDA、SCL 各需要到 **3.3V** 的上拉，短线实验可参考 4.7 kΩ；已带上拉的模块先核对板载电阻，不要随意重复并联。传感器供电处按手册加 10 μF 去耦，电源与地线尽量短。

| STM32 / 外设 | 接线 |
|---|---|
| PB0 / LED1 | 3.3V → 330 Ω 限流电阻 → LED 正极，LED 负极 → PB0 |
| PB1 / LED2 | 3.3V → 330 Ω 限流电阻 → LED 正极，LED 负极 → PB1 |
| PA9 / USART1_TX | USB 转 TTL 模块的 RXD |
| GND | USB 转 TTL 模块 GND，传感器 GND 共地 |
| PA10 / USART1_RX | 可选接 USB 转 TTL 的 TXD；只观察输出时可不接 |

串口适配器使用 **3.3V 逻辑电平**，不能直接连接 RS-232 电平口。开发板已有稳定供电时，不再把转串口模块 VCC 并到板上。PC13 不需要外接器件，也不承担运行指示。

## 3. 打开、编译、烧录

1. Keil μVision 5 打开根目录的 `P_2.uvprojx`，目标为 `P_2_HAL_AHT20_uCOS_II`。
2. 本工程按 **STM32F103C8：64 KB Flash / 20 KB SRAM、外部晶振 8 MHz**配置。若芯片或晶振不同，应核对 Device、存储范围和 `BSP/board.c` 时钟配置。
3. 使用 **ARM Compiler 5.06 update 5 (build 528)**。工程移植汇编面向 ARMCC5，切换 ARM Compiler 6 需要另行适配。
4. 执行 Rebuild。已验证结果：`0 Error(s), 0 Warning(s)`。
5. SWD 接 PA13/SWDIO、PA14/SWCLK、GND，调试器参考电压接板上 3.3V；需要复位连接时再接 NRST。BOOT0 保持低电平。
6. Debug / Utilities 选择实际使用的 ST-Link 或其他调试器，Port 选择 SW。Flash Download 配置应包含适用于 STM32F10x 中容量的片内 Flash 算法，起始地址 `0x08000000`、容量 `0x10000`。
7. 下载 `Objects/P_2.hex`，运行或复位。`Objects/P_2.bin` 也已提供，BIN 烧录地址同为 `0x08000000`。

之前提高调试器 Clock 后连接不稳定时，先恢复到已验证可用的低速 SWD，例如 100～400 kHz，检查短线、共地、电源和 NRST，再逐步尝试提高。这一 Clock 是调试链路速率，和工程的 72 MHz 系统时钟是两回事。本次只编译与仿真，未对实物执行下载。

命令行编译（默认工具链路径与本机一致；其他电脑可传入 `-KeilBin`）：

```powershell
powershell -ExecutionPolicy Bypass -File .\Tools\build_armcc.ps1
```

## 4. Windows 10 串口观察

在设备管理器确认 USB 转串口的 COM 号，在串口助手选择该端口，配置 **115200 波特率、8 数据位、无校验、1 停止位、无流控**，按文本显示并打开端口。PA9 要接适配器 RXD。

以下是输出格式示例，25.00 ℃ / 50.00 % 来自仿真输入，**不是现场实测值**：

```text
t=2000ms AHT20 T=25.00 C, RH=50.00 %
t=4000ms AHT20 T=25.00 C, RH=50.00 %
t=6000ms AHT20 T=25.00 C, RH=50.00 %
```

`t=` 是该任务的计划采样时隙开始时间；转换等待至少 80 ms，正常输出稍晚于该时间。2 s 指相邻触发的周期，而非把转换时间再叠加到 2 s 后。异常重初始化会让该时隙的实际触发推迟。文本只使用 ASCII，避免中文编码影响观察。

失败时输出 `ERROR=NACK`、`TIMEOUT`、`BUS`、`BUSY`、`CRC` 或 `CALIBRATION`，不会把错误伪装成 0 ℃ / 0 %。下一时隙尝试重新初始化。两路 LED 任务继续运行。

## 5. 源码入口与详细记录

| 文件 | 内容 |
|---|---|
| `App/main.c` | 三任务、绝对时间周期、串口格式化、采集重试 |
| `BSP/aht20.c` / `.h` | 上电、校准、触发、7 字节读数、CRC、定点换算 |
| `BSP/board.c` / `.h` | HAL RCC / GPIO / I2C1 / USART1、总线恢复 |
| `Config/stm32f1xx_hal_conf.h` | HAL 模块和晶振配置 |
| `Config/app_cfg.h` / `os_cfg.h` | 任务优先级、周期、OS 100 Hz、任务上限 3 |
| `Port/os_cpu_c.c` / `os_cpu_a.s` | Cortex-M3 调度、1 ms HAL / 10 ms OS 时基整合 |
| `Docs/任务二实验记录.md` | 软件 / 硬件 I²C、协议、移植集成全过程、验证结果 |
| `Docs/AHT20产品手册a2.pdf` | 用户提供的 AHT20 V1.2 手册 |
| `Docs/第三方源码说明.md` | ST HAL / CMSIS / μC/OS-II 来源与许可 |
| `Objects/keil_build.log` | 最终 Keil 编译记录 |
| `Objects/verify_*.json` | 十种 ARM 固件仿真场景与同一固件 SHA-256 |

已通过实际 ARM 固件指令仿真；寄存器事件、传感器响应和 SysTick 由模型提供，未验证真实电气时序与硬件。接线后仍需在实物上确认采集值、串口和 LED 周期。

更新：2026-10-28；PC13 心跳已移除。
