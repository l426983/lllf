#include "ucos_ii.h"
#include "board.h"
#include "aht20.h"
#include <stdio.h>

__align(8) static OS_STK s_led1_stack[APP_TASK_STACK_WORDS];
__align(8) static OS_STK s_led2_stack[APP_TASK_STACK_WORDS];
__align(8) static OS_STK s_uart_stack[APP_TASK_STACK_WORDS];

/* Watch these symbols in Keil. */
volatile INT32U g_led1_edges;
volatile INT32U g_led2_edges;
volatile INT32U g_uart_messages;
volatile INT32U g_led1_tick;
volatile INT32U g_led2_tick;
volatile INT32U g_uart_tick;
volatile INT32U g_sensor_samples;
volatile INT32U g_sensor_errors;
volatile INT32U g_sensor_last_error;
volatile INT32S g_temperature_centi_c;
volatile INT32U g_humidity_centi_rh;

static void DelayUntil(INT32U *deadline, INT32U period)
{
    INT32S remaining;
    OS_CPU_SR cpu_sr = 0u;
    *deadline += period;
    /* Prevent a tick between reading time and setting the delay. The nested
     * critical sections in OSTimeGet/OSTimeDly restore the previous PRIMASK.
     * PendSV runs only after this outer critical section is released. */
    OS_ENTER_CRITICAL();
    remaining = (INT32S)(*deadline - OSTimeGet());
    if (remaining > 0) {
        OSTimeDly((INT32U)remaining);
    } else if (remaining < 0) {
        *deadline = OSTimeGet(); /* resync after overrun; avoid catch-up burst */
    }
    OS_EXIT_CRITICAL();
}

static void TaskLED1(void *arg)
{
    INT32U deadline = 0u;
    unsigned int on = 1u;
    (void)arg;
    Board_StartTick(); /* Highest priority task starts the shared time base. */
    for (;;) {
        Board_SetLED(1u, on);
        g_led1_tick = OSTimeGet();
        ++g_led1_edges;
        on ^= 1u;
        DelayUntil(&deadline, APP_LED1_HALF_TICKS);
    }
}

static void TaskLED2(void *arg)
{
    INT32U deadline = 0u;
    unsigned int on = 1u;
    (void)arg;
    for (;;) {
        Board_SetLED(2u, on);
        g_led2_tick = OSTimeGet();
        ++g_led2_edges;
        on ^= 1u;
        DelayUntil(&deadline, APP_LED2_HALF_TICKS);
    }
}

static void TaskAHT20(void *arg)
{
    INT32U deadline = 0u;
    AHT20_Data data;
    AHT20_Result result;
    unsigned int ready;
    uint32_t magnitude;
    char line[96];
    (void)arg;
    result = AHT20_Init();
    ready = result == AHT20_OK;
    for (;;) {
        DelayUntil(&deadline, APP_UART_PERIOD_TICKS);
        g_uart_tick = OSTimeGet();
        if (!ready) {
            result = AHT20_Init();
            ready = result == AHT20_OK;
        }
        if (ready) { result = AHT20_Measure(&data); }
        g_sensor_last_error = (INT32U)result;
        if (result == AHT20_OK) {
            g_temperature_centi_c = data.temperature_centi_c;
            g_humidity_centi_rh = data.humidity_centi_rh;
            magnitude = (uint32_t)(data.temperature_centi_c < 0 ?
                                  -data.temperature_centi_c : data.temperature_centi_c);
            (void)snprintf(line, sizeof(line),
                "t=%lums AHT20 T=%s%lu.%02lu C, RH=%lu.%02lu %%\r\n",
                (unsigned long)g_uart_tick * 10ul,
                data.temperature_centi_c < 0 ? "-" : "",
                (unsigned long)(magnitude / 100u), (unsigned long)(magnitude % 100u),
                (unsigned long)(data.humidity_centi_rh / 100u),
                (unsigned long)(data.humidity_centi_rh % 100u));
            ++g_sensor_samples;
        } else {
            (void)snprintf(line, sizeof(line), "t=%lums AHT20 ERROR=%s\r\n",
                (unsigned long)g_uart_tick * 10ul, AHT20_ErrorName(result));
            ++g_sensor_errors;
            ready = 0u;
        }
        Board_SendString(line);
        ++g_uart_messages;
    }
}

static void CreateTask(void (*entry)(void *), OS_STK *stack,
                       INT8U prio, INT8U *name)
{
    INT8U err = OSTaskCreateExt(entry, (void *)0,
        &stack[APP_TASK_STACK_WORDS - 1u], prio, prio,
        &stack[0], APP_TASK_STACK_WORDS, (void *)0,
        OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);
    if (err != OS_ERR_NONE) { Board_Fatal(0x100u | err); }
    OSTaskNameSet(prio, name, &err);
    if (err != OS_ERR_NONE) { Board_Fatal(0x200u | err); }
}

int main(void)
{
    Board_Init();
    OSInit();
    CreateTask(TaskLED1, s_led1_stack, APP_LED1_PRIO, (INT8U *)"LED_2s");
    CreateTask(TaskLED2, s_led2_stack, APP_LED2_PRIO, (INT8U *)"LED_6s");
    CreateTask(TaskAHT20, s_uart_stack, APP_UART_PRIO, (INT8U *)"AHT20_2s");
    OSStart();
    Board_Fatal(0xE002u);
    return 0;
}

void HardFault_Handler(void) { Board_Fatal(0xF003u); }
void MemManage_Handler(void) { Board_Fatal(0xF004u); }
void BusFault_Handler(void)  { Board_Fatal(0xF005u); }
void UsageFault_Handler(void){ Board_Fatal(0xF006u); }
