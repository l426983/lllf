# 内核来源与裁剪说明

- 仓库：https://github.com/weston-embedded/uC-OS2
- 固定提交：`bfc6120f20cb27a927a9fc5dd667f9e455495777`
- 源文件头版本：V2.93.01；`OS_VERSION` 宏为上游原值 `29300u`。
- 获取日期：2026-10-28。
- 获取方式：GitHub API 的固定 Git blob；完整内核源文件未经编辑。
- 许可证：Apache-2.0，完整文本位于同目录 `LICENSE`。
- 编译文件：`Source/os_core.c`、`Source/os_task.c`、`Source/os_time.c`。
- 配套头文件：`Source/ucos_ii.h`、`Source/os_trace.h`。
- 裁剪方式：通过 `Config/os_cfg.h` 关闭未用的信号量、互斥量、事件标志、队列、
  邮箱、内存分区、软件定时器和统计任务，故无需编译相应模块。
- `Port/` 为本实验新写的 ARMCC5 Cortex-M3 端口，不是上游 ARMv7-M 端口的原样复制。

| 路径 | 上游 Git blob SHA-1 |
|---|---|
| Source/os_core.c | 84cbf2524d7caf33d592b2fb8491a8d3f1256d93 |
| Source/os_task.c | 3a1973857dac6700d60d699738039bb49258eaa7 |
| Source/os_time.c | 8d5aba4d4adb6fa828db0909dc9a8ce9169f3196 |
| Source/ucos_ii.h | b4cb14d62c0be29197c9b7a8d25e17ceac3f16c2 |
| Source/os_trace.h | 83e115542fe2d894a6e1cdd3958dc05cb254a2bf |
| LICENSE | d645695673349e3947e8e5ae42332d0ac3164cd7 |

P_2 沿用 P_1 的中容量启动汇编 `MDK-ARM/startup_stm32f10x_md.s`，
其最初来自本机 SPL V3.5.0 工程 `D:\QR——CSDN\QR_SY_1.0\QR_SY_2`。
为配合官方 HAL，P_2 的 `Drivers/CMSIS/*` 和 `BSP/system_stm32f1xx.c`
改用本机已有 STM32F1 HAL 工程中的配套文件，不再使用 P_1 的旧 CMSIS。
第三方来源详见 `Docs/第三方源码说明.md`；各源文件保留原始版权和许可声明。
