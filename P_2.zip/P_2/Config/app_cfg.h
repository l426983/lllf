#ifndef APP_CFG_H
#define APP_CFG_H

/* Full ON->OFF->ON cycles: 2 s and 6 s (50% duty). */
#define APP_LED1_HALF_TICKS     OS_TICKS_PER_SEC
#define APP_LED2_HALF_TICKS     (3u * OS_TICKS_PER_SEC)
#define APP_UART_PERIOD_TICKS   (2u * OS_TICKS_PER_SEC)
#define APP_TASK_STACK_WORDS    256u
#define APP_LED1_PRIO           5u
#define APP_LED2_PRIO           6u
#define APP_UART_PRIO           7u

#endif
